package com.negmdiarb.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.google.android.gms.location.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.util.*;

public class MainActivity extends ComponentActivity {
    ImageView photo;
    EditText name, phone, address, description;
    TextView location, status, imageCount;
    Uri photoUri;
    FusedLocationProviderClient fused;
    double lat = 0, lng = 0;
    final int CAM = 10, LOC = 11, GALLERY = 12;
    final ArrayList<Uri> imageUris = new ArrayList<>();

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        photo = findViewById(R.id.photo);
        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        address = findViewById(R.id.address);
        description = findViewById(R.id.description);
        location = findViewById(R.id.location);
        status = findViewById(R.id.status);
        imageCount = findViewById(R.id.imageCount);

        Spinner s = findViewById(R.id.category);
        s.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"مطاعم", "محلات", "عيادات", "أخرى"}));

        fused = LocationServices.getFusedLocationProviderClient(this);
        findViewById(R.id.btnPhoto).setOnClickListener(v -> takePhoto());
        findViewById(R.id.btnGallery).setOnClickListener(v -> pickImages());
        findViewById(R.id.btnLocation).setOnClickListener(v -> getLocation());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
    }

    void takePhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAM);
            return;
        }
        File dir = new File(getExternalFilesDir("Pictures"), "shops");
        dir.mkdirs();
        File f = new File(dir, "shop_" + System.currentTimeMillis() + ".jpg");
        photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i, 100);
    }

    void pickImages() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, GALLERY);
    }

    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (c != Activity.RESULT_OK) return;

        if (r == 100 && photoUri != null) {
            imageUris.add(photoUri);
            photo.setImageURI(photoUri);
            updateImageCount();
            runOcr();
        } else if (r == GALLERY && d != null) {
            if (d.getClipData() != null) {
                for (int x = 0; x < d.getClipData().getItemCount(); x++) {
                    addGalleryUri(d.getClipData().getItemAt(x).getUri());
                }
            } else if (d.getData() != null) {
                addGalleryUri(d.getData());
            }
            if (!imageUris.isEmpty()) photo.setImageURI(imageUris.get(imageUris.size() - 1));
            updateImageCount();
            status.setText("🖼️ تم اختيار الصور من الجهاز. راجع البيانات ثم احفظ.");
        }
    }

    void addGalleryUri(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        if (!imageUris.contains(uri)) imageUris.add(uri);
    }

    void updateImageCount() {
        imageCount.setText("🖼️ عدد الصور المختارة: " + imageUris.size());
    }

    void runOcr() {
        try {
            InputImage img = InputImage.fromFilePath(this, photoUri);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(img)
                    .addOnSuccessListener(res -> {
                        String t = res.getText();
                        if (name.getText().length() == 0 && !t.trim().isEmpty())
                            name.setText(t.split("\\n")[0]);
                        status.setText("تمت قراءة النص إن أمكن؛ راجع البيانات قبل الحفظ.");
                    })
                    .addOnFailureListener(e -> status.setText("تم التقاط الصورة. أدخل البيانات يدوياً إن لم تتم القراءة."));
        } catch (Exception e) {
            status.setText("تم التقاط الصورة.");
        }
    }

    void getLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOC);
            return;
        }
        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener(l -> {
            if (l != null) {
                lat = l.getLatitude();
                lng = l.getLongitude();
                location.setText(String.format(Locale.US, "الموقع: %.6f, %.6f", lat, lng));
            } else status.setText("لم يتم الحصول على الموقع؛ جرّب مرة أخرى.");
        });
    }

    void save() {
        String n = name.getText().toString().trim();
        if (n.isEmpty()) {
            name.setError("اكتب اسم المنشأة");
            return;
        }
        StringBuilder imgs = new StringBuilder();
        for (Uri u : imageUris) {
            if (imgs.length() > 0) imgs.append("||");
            imgs.append(u.toString());
        }
        getPreferences(MODE_PRIVATE).edit()
                .putString("last_business", n + "|" + phone.getText() + "|" + address.getText() + "|" + lat + "," + lng)
                .putString("last_images", imgs.toString())
                .apply();
        status.setText("✅ تم حفظ المنشأة على الهاتف (" + imageUris.size() + " صورة).");
        Toast.makeText(this, "تم الحفظ بنجاح", Toast.LENGTH_SHORT).show();
    }
}
