package com.negmdiarb.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.graphics.Color;
import android.widget.*;
import android.webkit.*;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.google.android.gms.location.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.*;
import com.google.android.gms.tasks.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.bumptech.glide.Glide;
import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends ComponentActivity {
    LinearLayout root,homePanel,addPanel,loginPanel,registerPanel,ownerPanel,adminPanel,offersPanel,servicePanel,
            businessList,requestList,ownerList,adminBusinessList,adminOfferList,adminComplaintList,adminRatingList,staffList,thumbs;
    EditText name,phone,whatsapp,facebook,address,description,search,loginPhone,loginPassword,regBusiness,regPhone,regPassword,
            offerTitle,offerDesc,offerDiscount,complaintText,hours,services,website;
    Spinner category,searchCategory;
    TextView addStatus,loginStatus,regStatus,ownerInfo,homeStatus,imageCount,location,offerStatus,adminStatus,statsText,serviceStatus;
    Spinner complaintType;
    Uri photoUri; File photoFile; final ArrayList<Uri> imageUris=new ArrayList<>();
    FusedLocationProviderClient fused; FirebaseAuth auth; FirebaseFirestore db; FirebaseStorage storage;
    double lat=0,lng=0; String editingBusinessId=""; final int CAM=10,LOC=11,GALLERY=12;
    boolean adminMode=false; String staffRole=""; String offerStartDate="",offerEndDate="";
    boolean cameraPending=false, restoreAddPanel=false;
    int adminTapCount=0; long lastAdminTap=0L;
    final Set<String> favoriteIds=new HashSet<>();
    final android.content.SharedPreferences adminPrefs(){return getSharedPreferences("negm_admin_session",MODE_PRIVATE);}
    boolean isMainAdmin(){return "admin".equals(staffRole);}
    boolean isStaff(){return "customer_service".equals(staffRole)||"establishment_reviewer".equals(staffRole)||"offers_manager".equals(staffRole);}
    boolean canManageRequests(){return isMainAdmin()||"establishment_reviewer".equals(staffRole);}
    boolean canManageOffers(){return isMainAdmin()||"offers_manager".equals(staffRole);}
    boolean canManageComplaints(){return isMainAdmin()||"customer_service".equals(staffRole);}
    String[] cats={"الكل","مطاعم","محلات","عيادات","صيدليات","خدمات","ملابس","إلكترونيات","مقاهي","مخابز","أخرى"};

    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);bind();
        restoreAddPanel=b!=null && b.getBoolean("restoreAddPanel",false);
        setup();installBackHandler();restoreUiState(b);
        // مهم: تهيئة Firebase أولًا حتى لا تحاول الشاشة الرئيسية قراءة auth/db قبل إنشائهما.
        initFirebase();
        // التطبيق يبدأ دائمًا من الرئيسية، إلا إذا كان قد أُعيد إنشاءه أثناء إضافة صورة.
        if(restoreAddPanel && (cameraPending || imageUris.size()>0)){
            show(addPanel);
        }else{
            showHome();
        }
    }

    void restoreUiState(Bundle b){
        if(b==null)return;
        name.setText(b.getString("f_name","")); phone.setText(b.getString("f_phone",""));
        whatsapp.setText(b.getString("f_whatsapp","")); facebook.setText(b.getString("f_facebook",""));
        address.setText(b.getString("f_address","")); description.setText(b.getString("f_description",""));
        hours.setText(b.getString("f_hours","")); services.setText(b.getString("f_services","")); website.setText(b.getString("f_website",""));
        editingBusinessId=b.getString("editingBusinessId",""); lat=b.getDouble("lat",0); lng=b.getDouble("lng",0);
        cameraPending=b.getBoolean("cameraPending",false);
        String pu=b.getString("photoUri",null); if(pu!=null)photoUri=Uri.parse(pu);
        String pf=b.getString("photoFile",null); if(pf!=null)photoFile=new File(pf);
        ArrayList<String> saved=b.getStringArrayList("imageUris");
        imageUris.clear(); if(saved!=null)for(String u:saved)try{imageUris.add(Uri.parse(u));}catch(Exception ignored){}
        if(lat!=0||lng!=0)location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));
        renderThumbs();
    }

    @Override protected void onSaveInstanceState(Bundle out){
        super.onSaveInstanceState(out);
        out.putBoolean("restoreAddPanel", restoreAddPanel || addPanel.getVisibility()==View.VISIBLE || cameraPending);
        out.putString("f_name",name.getText().toString()); out.putString("f_phone",phone.getText().toString());
        out.putString("f_whatsapp",whatsapp.getText().toString()); out.putString("f_facebook",facebook.getText().toString());
        out.putString("f_address",address.getText().toString()); out.putString("f_description",description.getText().toString());
        out.putString("f_hours",hours.getText().toString()); out.putString("f_services",services.getText().toString()); out.putString("f_website",website.getText().toString());
        out.putString("editingBusinessId",editingBusinessId); out.putDouble("lat",lat); out.putDouble("lng",lng);
        out.putBoolean("cameraPending",cameraPending); out.putString("photoUri",photoUri==null?null:photoUri.toString());
        out.putString("photoFile",photoFile==null?null:photoFile.getAbsolutePath());
        ArrayList<String> saved=new ArrayList<>(); for(Uri u:imageUris)saved.add(u.toString()); out.putStringArrayList("imageUris",saved);
    }

    void bind(){
        root=findViewById(R.id.root); homePanel=findViewById(R.id.homePanel); addPanel=findViewById(R.id.addPanel); loginPanel=findViewById(R.id.loginPanel); registerPanel=findViewById(R.id.registerPanel); ownerPanel=findViewById(R.id.ownerPanel); adminPanel=findViewById(R.id.adminPanel); offersPanel=findViewById(R.id.offersPanel); servicePanel=findViewById(R.id.servicePanel);
        businessList=findViewById(R.id.businessList); requestList=findViewById(R.id.requestList); ownerList=findViewById(R.id.ownerList); adminBusinessList=findViewById(R.id.adminBusinessList); adminOfferList=findViewById(R.id.adminOfferList); adminComplaintList=findViewById(R.id.adminComplaintList); adminRatingList=findViewById(R.id.adminRatingList); thumbs=findViewById(R.id.thumbs);
        name=findViewById(R.id.name);phone=findViewById(R.id.phone);whatsapp=findViewById(R.id.whatsapp);facebook=findViewById(R.id.facebook);address=findViewById(R.id.address);description=findViewById(R.id.description);hours=findViewById(R.id.hours);services=findViewById(R.id.services);website=findViewById(R.id.website);search=findViewById(R.id.search);loginPhone=findViewById(R.id.loginPhone);loginPassword=findViewById(R.id.loginPassword);regBusiness=findViewById(R.id.regBusiness);regPhone=findViewById(R.id.regPhone);regPassword=findViewById(R.id.regPassword);offerTitle=findViewById(R.id.offerTitle);offerDesc=findViewById(R.id.offerDesc);offerDiscount=findViewById(R.id.offerDiscount);complaintText=findViewById(R.id.complaintText);
        category=findViewById(R.id.category);searchCategory=findViewById(R.id.searchCategory);
        complaintType=findViewById(R.id.complaintType);
        addStatus=findViewById(R.id.addStatus);loginStatus=findViewById(R.id.loginStatus);regStatus=findViewById(R.id.regStatus);ownerInfo=findViewById(R.id.ownerInfo);homeStatus=findViewById(R.id.homeStatus);imageCount=findViewById(R.id.imageCount);location=findViewById(R.id.location);offerStatus=findViewById(R.id.offerStatus);adminStatus=findViewById(R.id.adminStatus);statsText=findViewById(R.id.statsText); serviceStatus=findViewById(R.id.serviceStatus);
    }

    void initFirebase(){
        auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance();
        try{
            String bucket=FirebaseApp.getInstance().getOptions().getStorageBucket();
            storage=(bucket!=null&&!bucket.trim().isEmpty())
                    ?FirebaseStorage.getInstance("gs://"+bucket.trim())
                    :FirebaseStorage.getInstance();
        }catch(Exception ex){
            try{storage=FirebaseStorage.getInstance();}catch(Exception ignored){storage=null;}
        }
        // تهيئة osmdroid بشكل صحيح حتى تظهر بلاطات الخريطة وتُحفظ ذاكرة التخزين المؤقت.
        try{
            Configuration.getInstance().load(this,getSharedPreferences("osmdroid",MODE_PRIVATE));
            Configuration.getInstance().setUserAgentValue("NegmDiarb/1.0");
            File base=new File(getExternalFilesDir(null),"osmdroid");
            File cache=new File(base,"tiles");
            if(!base.exists())base.mkdirs();
            if(!cache.exists())cache.mkdirs();
            Configuration.getInstance().setOsmdroidBasePath(base);
            Configuration.getInstance().setOsmdroidTileCache(cache);
        }catch(Exception ignored){
            try{Configuration.getInstance().setUserAgentValue("NegmDiarb/1.0");}catch(Exception ignored2){}
        }
        fused=LocationServices.getFusedLocationProviderClient(this);
        FirebaseUser current=auth.getCurrentUser();
        if(current!=null && !current.isAnonymous()){
            db.collection("users").document(current.getUid()).get().addOnSuccessListener(u->{
                String role=safe(u.getString("role"));
                if(truth(u,"enabled") && ("admin".equals(role)||"customer_service".equals(role)||"establishment_reviewer".equals(role)||"offers_manager".equals(role))){
                    // نحتفظ بالجلسة والصلاحيات فقط؛ لا نغيّر الشاشة الحالية أثناء بدء التطبيق أو الرجوع من الكاميرا.
                    adminMode=true;staffRole=role;applyRolePermissions();
                } else if("owner".equals(role) && truth(u,"enabled")){
                    // صاحب المنشأة يبقى مسجّلًا، لكن يبدأ من الرئيسية مثل أي مستخدم.
                    adminMode=false;staffRole="";loadFavorites();
                } else {auth.signOut();ensureAnon();loadFavorites();loadBusinesses();}
            }).addOnFailureListener(e->{
                // لا نغيّر الشاشة الحالية عند فشل الشبكة؛ المستخدم يظل على الرئيسية.
                loadFavorites();loadBusinesses();
            });
        } else { ensureAnon(); loadFavorites(); loadBusinesses(); }
    }

    void setup(){
        category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Arrays.copyOfRange(cats,1,cats.length)));
        searchCategory.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));
        findViewById(R.id.btnSearch).setOnClickListener(v->loadBusinesses());
        findViewById(R.id.btnNearby).setOnClickListener(v->loadNearby());
        findViewById(R.id.btnFavorites).setOnClickListener(v->loadFavoritesOnly());
        findViewById(R.id.btnFeatured).setOnClickListener(v->loadFeatured());
        findViewById(R.id.btnAll).setOnClickListener(v->{search.setText("");searchCategory.setSelection(0);loadBusinesses();});
        findViewById(R.id.btnRefresh).setOnClickListener(v->{loadFavorites();loadBusinesses();});
        findViewById(R.id.btnAdd).setVisibility(View.GONE);
        findViewById(R.id.btnAdd).setOnClickListener(v->Toast.makeText(this,"إضافة المنشآت متاحة للمدير الرئيسي فقط.",Toast.LENGTH_SHORT).show());
        // الإدارة مخفية عن المستخدمين. الدخول متاح من الاختصار السري على شعار التطبيق فقط.
        findViewById(R.id.btnAdmin).setVisibility(View.GONE);
        findViewById(R.id.btnAdmin).setOnClickListener(v->adminEntry());
        complaintType.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"شكوى","اقتراح","مشكلة تقنية"}));
        findViewById(R.id.btnAdminAddBusiness).setOnClickListener(v->{if(isMainAdmin()){clearForm();show(addPanel);}else toast("هذه الصلاحية للمدير الرئيسي فقط.");});
        findViewById(R.id.btnOwnerLogin).setOnClickListener(v->show(loginPanel));
        findViewById(R.id.btnRegister).setVisibility(View.GONE); // لا يوجد تسجيل ذاتي لصاحب المنشأة
        findViewById(R.id.btnRegisterOwner).setVisibility(View.GONE);
        // اختصار إداري مخفي: 7 ضغطات سريعة على شعار «نجم ديرب».
        findViewById(R.id.title).setOnClickListener(v->{
            long now=System.currentTimeMillis();
            if(now-lastAdminTap>3500L) adminTapCount=0;
            lastAdminTap=now;
            adminTapCount++;
            if(adminTapCount>=7){
                adminTapCount=0;
                adminEntry();
            }
        });
        findViewById(R.id.btnOffers).setOnClickListener(v->{loadOffers();show(offersPanel);});
        findViewById(R.id.btnService).setOnClickListener(v->show(servicePanel));
        findViewById(R.id.btnPhoto).setOnClickListener(v->takePhoto());
        findViewById(R.id.btnGallery).setOnClickListener(v->pickImages());
        findViewById(R.id.btnClearImages).setOnClickListener(v->clearAllImages());
        findViewById(R.id.btnLocation).setOnClickListener(v->getLocation());
        findViewById(R.id.btnMapPicker).setOnClickListener(v->openMapPicker());
        findViewById(R.id.btnSave).setOnClickListener(v->saveBusiness());
        findViewById(R.id.btnBackAdd).setOnClickListener(v->showHome());
        findViewById(R.id.btnBackLogin).setOnClickListener(v->showHome());
        findViewById(R.id.btnBackRegister).setOnClickListener(v->showHome());
        findViewById(R.id.btnLogin).setOnClickListener(v->ownerLogin());
        findViewById(R.id.btnRegisterOwner).setOnClickListener(v->registerOwner());
        findViewById(R.id.btnOwnerEdit).setOnClickListener(v->ownerEdit());
        findViewById(R.id.btnOwnerRequests).setOnClickListener(v->loadOwnerRequests());
        findViewById(R.id.btnOwnerOffers).setOnClickListener(v->{loadOwnerBusinesses();show(offersPanel);});
        findViewById(R.id.btnOwnerLogout).setOnClickListener(v->{auth.signOut();ensureAnon();showHome();});
        findViewById(R.id.btnAdminLogout).setOnClickListener(v->{adminMode=false;staffRole="";adminPrefs().edit().clear().apply();auth.signOut();ensureAnon();showHome();});
        findViewById(R.id.btnOfferStart).setOnClickListener(v->pickOfferDate(true));
        findViewById(R.id.btnOfferEnd).setOnClickListener(v->pickOfferDate(false));
        findViewById(R.id.btnAddOffer).setOnClickListener(v->addOffer());
        findViewById(R.id.btnBackOffers).setOnClickListener(v->showHome());
        findViewById(R.id.btnSendComplaint).setOnClickListener(v->sendComplaint());
        findViewById(R.id.btnBackService).setOnClickListener(v->showHome());
        findViewById(R.id.btnAdminRequests).setOnClickListener(v->loadRequests());
        findViewById(R.id.btnAdminOwners).setOnClickListener(v->loadOwners());
        findViewById(R.id.btnAdminBusinesses).setOnClickListener(v->loadAdminBusinesses());
        findViewById(R.id.btnAdminOffers).setOnClickListener(v->loadAdminOffers());
        findViewById(R.id.btnAdminComplaints).setOnClickListener(v->loadComplaints());
        findViewById(R.id.btnAdminRatings).setOnClickListener(v->loadRatings());
        findViewById(R.id.btnAdminStats).setOnClickListener(v->loadAdminStats());
        findViewById(R.id.btnAdminStaff).setOnClickListener(v->manageStaff());
        findViewById(R.id.btnStaffLogin).setOnClickListener(v->staffLogin());
        findViewById(R.id.btnStaffPublicLogin).setOnClickListener(v->staffLogin());
        findViewById(R.id.btnAdminAddOwner).setOnClickListener(v->createOwnerAccount());
        findViewById(R.id.btnAdminAddOffer).setOnClickListener(v->openAdminOfferForm());
        // التصنيفات السريعة تعمل فعليًا
        int[] ids={R.id.quickRestaurants,R.id.quickShops,R.id.quickClinics,R.id.quickPharmacies,R.id.quickServices,R.id.quickCafes,R.id.quickClothes,R.id.quickElectronics,R.id.quickBakeries};
        String[] values={"مطاعم","محلات","عيادات","صيدليات","خدمات","مقاهي","ملابس","إلكترونيات","مخابز"};
        for(int i=0;i<ids.length;i++){final String c=values[i];findViewById(ids[i]).setOnClickListener(v->{searchCategory.setSelection(indexOfCat(c));search.setText("");loadBusinesses();});}
    }

    int indexOfCat(String c){for(int i=0;i<cats.length;i++)if(cats[i].equals(c))return i;return 0;}
    void show(View v){homePanel.setVisibility(View.GONE);addPanel.setVisibility(View.GONE);loginPanel.setVisibility(View.GONE);registerPanel.setVisibility(View.GONE);ownerPanel.setVisibility(View.GONE);adminPanel.setVisibility(View.GONE);offersPanel.setVisibility(View.GONE);servicePanel.setVisibility(View.GONE);v.setVisibility(View.VISIBLE);}
    void showHome(){
        restoreAddPanel=false;cameraPending=false;
        boolean wasAdmin=adminMode;
        if(wasAdmin){
            adminMode=false;
            staffRole="";
            adminPrefs().edit().clear().apply();
            if(auth!=null){auth.signOut();ensureAnon();}
        }
        show(homePanel);
        if(auth!=null&&db!=null){loadFavorites();loadBusinesses();}
        homeStatus.setText("☁️ البيانات السحابية متصلة • البيانات المنشورة متاحة على الأجهزة المختلفة.");
    }
    void ensureAnon(){if(auth.getCurrentUser()==null)auth.signInAnonymously();}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String safe(String s){return s==null?"":s;}
    boolean truth(DocumentSnapshot d,String k){return Boolean.TRUE.equals(d.getBoolean(k));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void loadBusinesses(){
        if(db==null)return; businessList.removeAllViews();
        db.collection("businesses").whereEqualTo("status","approved").whereEqualTo("active",true).limit(200).get().addOnSuccessListener(s->{
            ArrayList<DocumentSnapshot> rows=new ArrayList<>();String term=search.getText().toString().trim().toLowerCase(Locale.ROOT);String cat=searchCategory.getSelectedItem()==null?"الكل":searchCategory.getSelectedItem().toString();
            for(DocumentSnapshot d:s){String n=safe(d.getString("name")),a=safe(d.getString("address")),sv=safe(d.getString("services")),ds=safe(d.getString("description")),ph=safe(d.getString("phone"));String hay=(n+" "+a+" "+sv+" "+ds+" "+ph).toLowerCase(Locale.ROOT);if(("الكل".equals(cat)||cat.equals(safe(d.getString("category"))))&&(term.isEmpty()||hay.contains(term)))rows.add(d);}
            Collections.sort(rows,(x,y)->{int f=Boolean.compare(!truth(y,"featured"),!truth(x,"featured"));if(f!=0)return f;com.google.firebase.Timestamp tx=x.getTimestamp("createdAt"),ty=y.getTimestamp("createdAt");if(tx!=null&&ty!=null){int t=ty.compareTo(tx);if(t!=0)return t;}double ax=num(x,"ratingAvg"),by=num(y,"ratingAvg");int r=Double.compare(by,ax);if(r!=0)return r;return safe(y.getString("name")).compareToIgnoreCase(safe(x.getString("name")));});
            if(rows.isEmpty())addText(businessList,"لا توجد منشآت مطابقة حاليًا. جرّب كلمة أخرى أو تصنيفًا مختلفًا.");
            for(DocumentSnapshot d:rows)addBusinessCard(d);
        }).addOnFailureListener(e->addText(businessList,"تعذر تحميل البيانات. تأكد من الإنترنت ثم اضغط تحديث."));
    }
    double num(DocumentSnapshot d,String k){Double x=d.getDouble(k);return x==null?0:x;}
    void loadFavorites(){favoriteIds.clear();if(auth==null||db==null)return;FirebaseUser u=auth.getCurrentUser();if(u==null)return;db.collection("favorites").whereEqualTo("uid",u.getUid()).limit(500).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s)favoriteIds.add(safe(d.getString("businessId")));});}
    void loadFavoritesOnly(){
        businessList.removeAllViews();
        if(favoriteIds.isEmpty()){addText(businessList,"❤️ لا توجد منشآت محفوظة في المفضلة بعد.");return;}
        ArrayList<String> ids=new ArrayList<>(favoriteIds);
        loadFavoriteBatch(ids,0);
    }
    void loadFavoriteBatch(ArrayList<String> ids,int from){
        if(from>=ids.size())return;
        int to=Math.min(from+10,ids.size());
        db.collection("businesses").whereIn(FieldPath.documentId(),ids.subList(from,to)).get().addOnSuccessListener(s->{
            for(DocumentSnapshot d:s)if(truth(d,"active")&&"approved".equals(d.getString("status")))addBusinessCard(d);
            loadFavoriteBatch(ids,to);
        }).addOnFailureListener(e->{if(from==0)addText(businessList,"تعذر تحميل المفضلة.");});
    }
    void loadFeatured(){
        businessList.removeAllViews();
        db.collection("businesses").whereEqualTo("status","approved").whereEqualTo("active",true).whereEqualTo("featured",true).limit(100).get().addOnSuccessListener(s->{
            if(s.isEmpty()){addText(businessList,"⭐ لا توجد منشآت مميزة حاليًا.");return;}
            ArrayList<DocumentSnapshot> rows=new ArrayList<>();for(DocumentSnapshot d:s)rows.add(d);
            Collections.sort(rows,(a,b)->Double.compare(num(b,"ratingAvg"),num(a,"ratingAvg")));
            for(DocumentSnapshot d:rows)addBusinessCard(d);
        }).addOnFailureListener(e->addText(businessList,"تعذر تحميل المنشآت المميزة."));
    }

    void addBusinessCard(DocumentSnapshot d){
        LinearLayout card=box();String n=safe(d.getString("name"));double avg=num(d,"ratingAvg");long cnt=d.getLong("ratingCount")==null?0:d.getLong("ratingCount");
        String badge=truth(d,"featured")?" ⭐ مميز":"";String fav=favoriteIds.contains(d.getId())?"❤️":"🤍";
        String desc=safe(d.getString("description"));if(desc.length()>90)desc=desc.substring(0,90)+"…";
        TextView t=tv("🏪 "+n+badge+"\n📂 "+safe(d.getString("category"))+"  •  ⭐ "+(avg==0?"جديد":String.format(Locale.US,"%.1f (%d)",avg,cnt))+"\n📍 "+safe(d.getString("address"))+(desc.isEmpty()?"":"\n"+desc));
        card.addView(t);LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);
        Button mapBtn=btn("🗺️"),callBtn=btn("📞"),waBtn=btn("💬"),rateBtn=btn("⭐"),favBtn=btn(fav),shareBtn=btn("📤");
        a.addView(mapBtn);a.addView(callBtn);a.addView(waBtn);a.addView(rateBtn);a.addView(favBtn);a.addView(shareBtn);card.addView(a);
        card.setOnClickListener(v->{logEvent("businessViews",d.getId());showBusinessDetails(d);});
        mapBtn.setOnClickListener(v->{logEvent("mapClicks",d.getId());openMap(d);});callBtn.setOnClickListener(v->{logEvent("callClicks",d.getId());call(d.getString("phone"));});waBtn.setOnClickListener(v->{logEvent("whatsappClicks",d.getId());wa(d.getId(),d.getString("whatsapp"));});rateBtn.setOnClickListener(v->showRatingDialog(d.getId()));
        favBtn.setOnClickListener(v->toggleFavorite(d.getId(),favBtn));shareBtn.setOnClickListener(v->shareBusiness(d));businessList.addView(card);
    }
    void toggleFavorite(String bid,Button button){FirebaseUser u=auth.getCurrentUser();if(u==null)return;String id=u.getUid()+"_"+bid;DocumentReference r=db.collection("favorites").document(id);if(favoriteIds.contains(bid)){r.delete().addOnSuccessListener(x->{favoriteIds.remove(bid);button.setText("🤍");});}else{Map<String,Object>m=new HashMap<>();m.put("uid",u.getUid());m.put("businessId",bid);m.put("createdAt",FieldValue.serverTimestamp());r.set(m).addOnSuccessListener(x->{favoriteIds.add(bid);button.setText("❤️");logEvent("favoriteClicks",bid);});}}
    void logEvent(String collection,String bid){FirebaseUser u=auth.getCurrentUser();if(u==null)return;Map<String,Object>m=new HashMap<>();m.put("businessId",bid);m.put("uid",u.getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection(collection).add(m);}

    void showBusinessDetails(DocumentSnapshot d){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(18,10,18,10);
        double avg=num(d,"ratingAvg");long cnt=d.getLong("ratingCount")==null?0:d.getLong("ratingCount");String title=safe(d.getString("name"));
        TextView head=tv("🏪 "+title);head.setTextSize(22);head.setTypeface(null,android.graphics.Typeface.BOLD);l.addView(head);
        l.addView(tv("📂 "+safe(d.getString("category"))));String desc=safe(d.getString("description"));if(!desc.isEmpty())l.addView(tv("📝 "+desc));
        l.addView(tv("📍 "+safe(d.getString("address"))));String ph=safe(d.getString("phone"));if(!ph.isEmpty())l.addView(tv("📞 "+ph));String hoursText=safe(d.getString("hours"));if(!hoursText.isEmpty())l.addView(tv("🕒 "+hoursText));String servicesText=safe(d.getString("services"));if(!servicesText.isEmpty())l.addView(tv("🛠️ "+servicesText));
        l.addView(tv("⭐ "+(avg==0?"جديد":String.format(Locale.US,"%.1f من %d تقييم",avg,cnt))));
        Object imgsObj=d.get("imageUrls");
        if(imgsObj instanceof List){
            List<?> imgs=(List<?>)imgsObj;
            if(!imgs.isEmpty()){
                TextView it=tv("📸 صور المنشأة");it.setTypeface(null,android.graphics.Typeface.BOLD);l.addView(it);
                LinearLayout imgRow=new LinearLayout(this);imgRow.setOrientation(LinearLayout.HORIZONTAL);
                HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.addView(imgRow);
                for(Object o:imgs){if(o==null)continue;ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);imgRow.addView(iv,new LinearLayout.LayoutParams(170,130));try{Glide.with(this).load(String.valueOf(o)).centerCrop().into(iv);}catch(Exception ignored){}}
                l.addView(hsv);
            }
        }
        String web=safe(d.getString("website")),fb=safe(d.getString("facebook"));LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.VERTICAL);
        Button map=btn("🗺️ التوجه للمكان عبر خرائط Google");a.addView(map);map.setOnClickListener(v->{logEvent("mapClicks",d.getId());openMap(d);});
        Button call=btn("📞 اتصال");a.addView(call);call.setOnClickListener(v->{logEvent("callClicks",d.getId());call(d.getString("phone"));});
        Button wa=btn("💬 واتساب");a.addView(wa);wa.setOnClickListener(v->{logEvent("whatsappClicks",d.getId());wa(d.getId(),d.getString("whatsapp"));});
        if(!web.isEmpty()){Button wb=btn("🌐 الموقع الإلكتروني");a.addView(wb);wb.setOnClickListener(v->openExternal(web));}
        if(!fb.isEmpty()){Button f=btn("📘 فيسبوك");a.addView(f);f.setOnClickListener(v->openExternal(fb));}
        Button share=btn("📤 مشاركة المنشأة");a.addView(share);share.setOnClickListener(v->shareBusiness(d));Button r=btn("⭐ اكتب تقييمًا");a.addView(r);r.setOnClickListener(v->showRatingDialog(d.getId()));
        l.addView(a);
        db.collection("offers").whereEqualTo("businessId",d.getId()).whereEqualTo("active",true).limit(20).get().addOnSuccessListener(s->{String td=today();for(DocumentSnapshot o:s){String st=safe(o.getString("startDate")),en=safe(o.getString("endDate"));if((st.isEmpty()||st.compareTo(td)<=0)&&(en.isEmpty()||en.compareTo(td)>=0)){l.addView(tv("🎁 عرض: "+safe(o.getString("title"))+" — "+safe(o.getString("discount"))));}}});
        new AlertDialog.Builder(this).setTitle("تفاصيل المنشأة").setView(l).setPositiveButton("إغلاق",null).show();
    }
    void openExternal(String url){String u=url.trim();if(!u.startsWith("http://")&&!u.startsWith("https://"))u="https://"+u;try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("الرابط غير متاح.");}}
    void shareBusiness(DocumentSnapshot d){String n=safe(d.getString("name")),a=safe(d.getString("address"));Double la=d.getDouble("lat"),lo=d.getDouble("lng");String msg="⭐ "+n+"\n📍 "+a;if(la!=null&&lo!=null)msg+="\n🗺️ https://www.google.com/maps/search/?api=1&query="+la+","+lo;Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,msg);startActivity(Intent.createChooser(i,"مشاركة المنشأة"));}

    void loadNearby(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOC);return;}
        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,null).addOnSuccessListener(me->{if(me==null){homeStatus.setText("تعذر تحديد موقعك.");return;}db.collection("businesses").whereEqualTo("status","approved").whereEqualTo("active",true).limit(200).get().addOnSuccessListener(s->{ArrayList<DocumentSnapshot>rows=new ArrayList<>();for(DocumentSnapshot d:s)rows.add(d);final double la=me.getLatitude(),lo=me.getLongitude();Collections.sort(rows,(a,b)->Double.compare(distanceKm(la,lo,a),distanceKm(la,lo,b)));businessList.removeAllViews();if(rows.isEmpty())addText(businessList,"لا توجد منشآت منشورة.");for(DocumentSnapshot d:rows)addBusinessCardWithDistance(d,la,lo);homeStatus.setText("📍 تم ترتيب المنشآت من الأقرب إلى الأبعد.");});}).addOnFailureListener(e->homeStatus.setText("تعذر تحديد الموقع: "+safe(e.getMessage())));
    }
    void addBusinessCardWithDistance(DocumentSnapshot d,double la,double lo){addBusinessCard(d);int i=businessList.getChildCount()-1;LinearLayout card=(LinearLayout)businessList.getChildAt(i);TextView dist=tv(String.format(Locale.US,"📏 المسافة: %.2f كم",distanceKm(la,lo,d)));card.addView(dist,1);}
    double distanceKm(double la,double lo,DocumentSnapshot d){Double a=d.getDouble("lat"),b=d.getDouble("lng");if(a==null||b==null)return 999999;double R=6371.0,dl=Math.toRadians(a-la),do_=Math.toRadians(b-lo);double x=Math.sin(dl/2)*Math.sin(dl/2)+Math.cos(Math.toRadians(la))*Math.cos(Math.toRadians(a))*Math.sin(do_/2)*Math.sin(do_/2);return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));}

    void loadOffers(){
        findViewById(R.id.offerForm).setVisibility(View.GONE);LinearLayout list=findViewById(R.id.offerList);list.removeAllViews();String td=today();
        db.collection("offers").whereEqualTo("active",true).limit(200).get().addOnSuccessListener(s->{boolean any=false;for(DocumentSnapshot d:s){String st=safe(d.getString("startDate")),en=safe(d.getString("endDate"));if(!en.isEmpty()&&en.compareTo(td)<0)continue;if(!st.isEmpty()&&st.compareTo(td)>0)continue;any=true;LinearLayout c=box();c.addView(tv("🎁 "+safe(d.getString("title"))+"\n"+safe(d.getString("description"))+"\n💰 "+safe(d.getString("discount"))+"\n📅 "+st+" → "+en));list.addView(c);}if(!any)addText(list,"لا توجد عروض سارية حاليًا.");}).addOnFailureListener(e->addText(list,"تعذر تحميل العروض."));
    }
    void pickOfferDate(boolean start){Calendar c=Calendar.getInstance();new DatePickerDialog(this,(v,y,m,d)->{String s=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);if(start){offerStartDate=s;TextView t=findViewById(R.id.offerStartStatus);t.setVisibility(View.VISIBLE);t.setText("📅 بداية: "+s);}else{offerEndDate=s;TextView t=findViewById(R.id.offerEndStatus);t.setVisibility(View.VISIBLE);t.setText("📅 نهاية: "+s);}},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void addOffer(){
        FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){offerStatus.setText("سجل دخول صاحب المنشأة أولًا.");return;}String title=offerTitle.getText().toString().trim();if(title.isEmpty()){offerStatus.setText("اكتب عنوان العرض.");return;}if(!offerStartDate.isEmpty()&&!offerEndDate.isEmpty()&&offerEndDate.compareTo(offerStartDate)<0){offerStatus.setText("تاريخ النهاية يجب أن يكون بعد البداية.");return;}
        if(isMainAdmin()){String bid=safe((String)findViewById(R.id.offerForm).getTag());if(bid.isEmpty()){offerStatus.setText("حدد منشأة للعرض من الإدارة.");return;}writeOffer(bid,"",true);return;}
        db.collection("users").document(u.getUid()).get().addOnSuccessListener(us->{String bid=safe(us.getString("businessId"));if(bid.isEmpty()){offerStatus.setText("لا توجد منشأة مرتبطة بالحساب.");return;}writeOffer(bid,u.getUid(),false);});
    }
    void writeOffer(String bid,String ownerUid,boolean admin){Map<String,Object>m=new HashMap<>();m.put("businessId",bid);m.put("ownerUid",ownerUid);m.put("startDate",offerStartDate);m.put("endDate",offerEndDate);m.put("title",offerTitle.getText().toString().trim());m.put("description",offerDesc.getText().toString().trim());m.put("discount",offerDiscount.getText().toString().trim());m.put("active",admin);m.put("status",admin?"approved":"pending");m.put("featured",false);m.put("createdAt",FieldValue.serverTimestamp());db.collection("offers").add(m).addOnSuccessListener(x->{offerStatus.setText(admin?"✅ تم نشر العرض.":"✅ تم إرسال العرض للمراجعة.");offerTitle.setText("");offerDesc.setText("");offerDiscount.setText("");offerStartDate="";offerEndDate="";}).addOnFailureListener(e->offerStatus.setText("تعذر حفظ العرض: "+safe(e.getMessage())));}

    void saveBusiness(){
        FirebaseUser u=auth.getCurrentUser();String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("اكتب اسم المنشأة");return;}if(u==null||u.isAnonymous()){addStatus.setText("⛔ سجل الدخول بالحساب المناسب أولًا.");return;}if(lat==0&&lng==0){addStatus.setText("📍 حدد موقع المنشأة قبل الحفظ.");return;}
        if(isMainAdmin())saveBusinessAsAdmin();else db.collection("users").document(u.getUid()).get().addOnSuccessListener(userDoc->{if(!"owner".equals(userDoc.getString("role"))||!truth(userDoc,"enabled")){addStatus.setText("⛔ لا تملك صلاحية إرسال تعديل.");return;}String bid=safe(userDoc.getString("businessId"));if(bid.isEmpty()){addStatus.setText("ℹ️ الحساب غير مرتبط بمنشأة بعد. الربط يتم عن طريق الإدارة.");return;}Map<String,Object>changes=businessFields(false);Map<String,Object>req=new HashMap<>();req.put("businessId",bid);req.put("ownerUid",u.getUid());req.put("changes",changes);req.put("status","pending");req.put("createdAt",FieldValue.serverTimestamp());addStatus.setText("☁️ جاري إرسال التعديل للمراجعة...");db.collection("changeRequests").add(req).addOnSuccessListener(x->addStatus.setText("✅ تم إرسال التعديل للإدارة. لن يظهر للعامة إلا بعد الموافقة.")).addOnFailureListener(e->addStatus.setText("❌ تعذر إرسال الطلب: "+safe(e.getMessage())));});
    }
    Map<String,Object> businessFields(boolean adminCreate){Map<String,Object>b=new HashMap<>();b.put("name",name.getText().toString().trim());b.put("phone",phone.getText().toString().trim());b.put("whatsapp",normalizeEgyptPhone(whatsapp.getText().toString().trim()));b.put("facebook",facebook.getText().toString().trim());b.put("address",address.getText().toString().trim());b.put("description",description.getText().toString().trim());b.put("hours",hours.getText().toString().trim());b.put("services",services.getText().toString().trim());b.put("website",website.getText().toString().trim());b.put("category",category.getSelectedItem()==null?"أخرى":category.getSelectedItem().toString());b.put("lat",lat);b.put("lng",lng);if(adminCreate){b.put("ratingAvg",0);b.put("ratingCount",0);b.put("active",true);b.put("featured",false);b.put("ownerUid",safe((String)getIntent().getStringExtra("ownerUid")));b.put("status","approved");b.put("updatedAt",FieldValue.serverTimestamp());}return b;}
    void saveBusinessAsAdmin(){
        if(!isMainAdmin()){addStatus.setText("⛔ المدير الرئيسي فقط يستطيع حفظ المنشآت.");return;}
        final Button saveBtn=findViewById(R.id.btnSave);
        saveBtn.setEnabled(false); saveBtn.setText("⏳ جاري الحفظ...");
        final boolean creating=editingBusinessId.isEmpty();
        final String id=creating?db.collection("businesses").document().getId():editingBusinessId;
        final Map<String,Object> b=businessFields(creating);
        b.remove("createdAt");
        addStatus.setText(imageUris.isEmpty()?"☁️ جاري حفظ بيانات المنشأة...":"☁️ جاري حفظ البيانات ثم رفع الصور بأمان...");
        if(creating)b.put("createdAt",FieldValue.serverTimestamp());

        db.collection("businesses").document(id).set(b,SetOptions.merge())
            .addOnSuccessListener(saved->{
                editingBusinessId=id;
                if(imageUris.isEmpty()){
                    finishBusinessSave(saveBtn,"✅ تم حفظ المنشأة على السحابة.");
                    return;
                }
                addStatus.setText("✅ البيانات محفوظة. جاري رفع "+imageUris.size()+" صورة...\nلا تغلق الشاشة حتى يكتمل الرفع.");
                uploadBusinessImages(id).addOnSuccessListener(newUrls->{
                    mergeImageUrls(id,newUrls,saveBtn);
                }).addOnFailureListener(e->{
                    saveBtn.setEnabled(true);saveBtn.setText("💾 حفظ البيانات");
                    addStatus.setText("✅ تم حفظ بيانات المنشأة، لكن رفع الصور تعذر. يمكنك الضغط على حفظ مرة أخرى لإعادة المحاولة.\n"+storageErrorMessage(e));
                });
            })
            .addOnFailureListener(e->{
                saveBtn.setEnabled(true);saveBtn.setText("💾 حفظ البيانات");
                addStatus.setText("❌ تعذر حفظ بيانات المنشأة: "+safe(e.getMessage()));
            });
    }

    void mergeImageUrls(String id,List<String>newUrls,Button saveBtn){
        db.collection("businesses").document(id).get().addOnSuccessListener(doc->{
            ArrayList<String> merged=new ArrayList<>();
            Object old=doc.get("imageUrls");
            if(old instanceof List)for(Object o:(List<?>)old)if(o!=null)merged.add(String.valueOf(o));
            for(String u:newUrls)if(u!=null&&!u.isEmpty()&&!merged.contains(u))merged.add(u);
            HashMap<String,Object> patch=new HashMap<>();patch.put("imageUrls",merged);patch.put("updatedAt",FieldValue.serverTimestamp());
            db.collection("businesses").document(id).set(patch,SetOptions.merge())
                .addOnSuccessListener(x->{
                    imageUris.clear();renderThumbs();
                    finishBusinessSave(saveBtn,"✨ تم حفظ المنشأة ورفع كل الصور بنجاح.\n🖼️ تم تثبيت الصور على السحابة.");
                })
                .addOnFailureListener(e->{saveBtn.setEnabled(true);saveBtn.setText("💾 حفظ البيانات");addStatus.setText("✅ تم رفع الصور، لكن تعذر تحديث سجل الصور: "+safe(e.getMessage()));});
        }).addOnFailureListener(e->{saveBtn.setEnabled(true);saveBtn.setText("💾 حفظ البيانات");addStatus.setText("✅ تم رفع الصور، لكن تعذر قراءة السجل لتثبيتها: "+safe(e.getMessage()));});
    }

    void finishBusinessSave(Button saveBtn,String message){
        saveBtn.setEnabled(true);saveBtn.setText("💾 حفظ البيانات");
        addStatus.setText(message);
        Toast.makeText(this,"✨ نجم ديرب: تم الحفظ",Toast.LENGTH_SHORT).show();
        loadBusinesses();
    }

    Task<List<String>> uploadBusinessImages(String businessId){
        if(storage==null)return Tasks.forException(new IllegalStateException("Firebase Storage غير مهيأ."));
        ArrayList<Task<String>> tasks=new ArrayList<>();
        for(int i=0;i<imageUris.size();i++){
            final Uri u=imageUris.get(i);
            final String fn=System.currentTimeMillis()+"_"+UUID.randomUUID().toString().replace("-","")+".jpg";
            final StorageReference ref=storage.getReference().child("businessImages").child(businessId).child(fn);
            StorageMetadata meta=new StorageMetadata.Builder().setContentType("image/jpeg").build();
            Task<String> one=ref.putFile(u,meta).continueWithTask(t->{
                if(!t.isSuccessful())throw Objects.requireNonNull(t.getException());
                // نتأكد أن الملف ظهر فعلًا قبل طلب رابط التنزيل، لتجنب خطأ Object does not exist at: location.
                return ref.getMetadata().continueWithTask(m->{
                    if(!m.isSuccessful())throw Objects.requireNonNull(m.getException());
                    return ref.getDownloadUrl();
                });
            }).continueWith(t->{
                if(!t.isSuccessful())throw Objects.requireNonNull(t.getException());
                return t.getResult().toString();
            });
            tasks.add(one);
        }
        if(tasks.isEmpty())return Tasks.forResult(new ArrayList<>());
        return Tasks.whenAllSuccess(tasks).continueWith(t->{
            ArrayList<String>out=new ArrayList<>();
            for(Object o:t.getResult())out.add(String.valueOf(o));
            return out;
        });
    }

    String storageErrorMessage(Exception e){
        if(e instanceof StorageException){
            int c=((StorageException)e).getErrorCode();
            if(c==StorageException.ERROR_BUCKET_NOT_FOUND)return"⚠️ Cloud Storage غير مفعّل أو الـ bucket غير موجود في مشروع Firebase.";
            if(c==StorageException.ERROR_OBJECT_NOT_FOUND)return"⚠️ تم رفع الطلب لكن ملف الصورة غير موجود بعد. إعادة المحاولة تعالج الحالات المؤقتة.";
            if(c==StorageException.ERROR_QUOTA_EXCEEDED)return"⚠️ تم تجاوز حد التخزين. راجع خطة Firebase/الفوترة.";
            if(c==StorageException.ERROR_NOT_AUTHENTICATED)return"⚠️ جلسة Firebase انتهت. أعد دخول الإدارة ثم جرّب مرة أخرى.";
            if(c==StorageException.ERROR_NOT_AUTHORIZED)return"⚠️ قواعد Storage تمنع رفع الصورة لهذا الحساب.";
        }
        return "⚠️ تفاصيل: "+safe(e==null?null:e.getMessage());
    }

    void ownerEdit(){FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){show(loginPanel);return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(d->{String bid=safe(d.getString("businessId"));if(bid.isEmpty()){toast("المنشأة يتم ربطها بالحساب عن طريق الإدارة فقط.");return;}db.collection("businesses").document(bid).get().addOnSuccessListener(b->{if(b.exists()){editingBusinessId=bid;fillBusiness(b);addStatus.setText("✏️ عدّل البيانات ثم اضغط حفظ لإرسال طلب للمراجعة.");show(addPanel);}});});}
    void loadOwnerBusinesses(){findViewById(R.id.offerForm).setVisibility(View.VISIBLE);}
    void loadOwnerRequests(){FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){show(loginPanel);return;}LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);db.collection("changeRequests").whereEqualTo("ownerUid",u.getUid()).limit(50).get().addOnSuccessListener(s->{if(s.isEmpty())l.addView(tv("لا توجد طلبات تعديل."));for(DocumentSnapshot d:s){Map<String,Object>ch=(Map<String,Object>)d.get("changes");String nm=ch==null?"":safe((String)ch.get("name"));l.addView(tv("🕐 الحالة: "+safe(d.getString("status"))+"\n🏪 المنشأة: "+nm+"\n📅 الطلب: "+safe(d.getId())));}new AlertDialog.Builder(this).setTitle("طلبات التعديل").setView(l).setPositiveButton("إغلاق",null).show();});}

    void registerOwner(){toast("التسجيل الذاتي متوقف. إنشاء حساب صاحب المنشأة يتم بواسطة المدير فقط.");}
    String loginEmail(String p){String x=p.trim();if(x.contains("@"))return x;return x.replaceAll("[^0-9]","")+"@negmdiarb.app";}
    void ownerLogin(){String id=loginPhone.getText().toString().trim(),pw=loginPassword.getText().toString();if(id.isEmpty()||pw.length()<6){loginStatus.setText("أدخل البريد/رقم الهاتف وكلمة المرور.");return;}auth.signInWithEmailAndPassword(loginEmail(id),pw).addOnSuccessListener(r->db.collection("users").document(r.getUser().getUid()).get().addOnSuccessListener(d->{if(!truth(d,"enabled")||!"owner".equals(d.getString("role"))){loginStatus.setText("⛔ الحساب غير مفعل أو ليس حساب صاحب منشأة.");auth.signOut();ensureAnon();return;}loadFavorites();showOwner();})).addOnFailureListener(e->loginStatus.setText("بيانات الدخول غير صحيحة أو الحساب غير موجود."));}
    void showOwner(){FirebaseUser u=auth.getCurrentUser();if(u==null){show(loginPanel);return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(d->{ownerInfo.setText("👤 "+safe(d.getString("displayName"))+"\n📞 "+safe(d.getString("phone"))+"\nحالة الحساب: "+(truth(d,"enabled")?"مفعل":"موقوف")+"\n🏪 المنشأة المرتبطة: "+safe(d.getString("businessId")));show(ownerPanel);});}

    void adminEntry(){
        // لا نستعلم عن users للزائر المجهول؛ قواعد Firestore تمنع هذا الاستعلام عمدًا.
        // شاشة الدخول نفسها هي نقطة التحقق، ثم نتحقق من role/enabled داخل وثيقة المستخدم.
        FirebaseUser current=auth.getCurrentUser();
        if(current!=null&&!current.isAnonymous()){
            db.collection("users").document(current.getUid()).get().addOnSuccessListener(u->{
                if("admin".equals(u.getString("role"))&&truth(u,"enabled")){
                    adminMode=true;
                    staffRole="admin";
                    adminPrefs().edit().putBoolean("logged_in",true).putString("uid",current.getUid()).apply();
                    show(adminPanel);
                    applyRolePermissions();
                    loadRoleData();
                } else {
                    adminLogin();
                }
            }).addOnFailureListener(e->toast("تعذر قراءة حساب الإدارة. تأكد من اتصال الإنترنت ثم حاول مرة أخرى."));
            return;
        }
        adminLogin();
    }
    void showFirstAdminSetup(){adminLogin();}
    void adminLogin(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);EditText em=new EditText(this);em.setHint("بريد المدير");EditText pw=new EditText(this);pw.setHint("كلمة المرور");pw.setInputType(0x81);l.addView(em);l.addView(pw);new AlertDialog.Builder(this).setTitle("دخول الإدارة").setView(l).setPositiveButton("دخول",(d,w)->adminSignIn(em.getText().toString().trim(),pw.getText().toString())).setNegativeButton("إلغاء",null).show();}
    void adminSignIn(String email,String password){if(email.isEmpty()||password.length()<6){toast("أدخل البريد وكلمة المرور بشكل صحيح.");return;}auth.signInWithEmailAndPassword(email,password).addOnSuccessListener(r->db.collection("users").document(r.getUser().getUid()).get().addOnSuccessListener(u->{if("admin".equals(u.getString("role"))&&truth(u,"enabled")){adminMode=true;staffRole="admin";adminPrefs().edit().putBoolean("logged_in",true).putString("uid",r.getUser().getUid()).apply();show(adminPanel);applyRolePermissions();loadRoleData();}else{auth.signOut();ensureAnon();toast("الحساب ليس مديرًا رئيسيًا.");}})).addOnFailureListener(e->toast("بيانات المدير غير صحيحة."));}
    void staffLogin(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);EditText em=new EditText(this);em.setHint("بريد الموظف");EditText pw=new EditText(this);pw.setHint("كلمة المرور");pw.setInputType(0x81);l.addView(em);l.addView(pw);new AlertDialog.Builder(this).setTitle("دخول الموظفين").setView(l).setPositiveButton("دخول",(d,w)->auth.signInWithEmailAndPassword(em.getText().toString().trim(),pw.getText().toString()).addOnSuccessListener(r->db.collection("users").document(r.getUser().getUid()).get().addOnSuccessListener(u->{String role=safe(u.getString("role"));if(("customer_service".equals(role)||"establishment_reviewer".equals(role)||"offers_manager".equals(role))&&truth(u,"enabled")){adminMode=true;staffRole=role;show(adminPanel);adminStatus.setText("👤 حساب موظف — "+roleLabel(role));applyRolePermissions();loadRoleData();}else{auth.signOut();ensureAnon();toast("الحساب غير صالح للموظفين أو موقوف.");}})).addOnFailureListener(e->toast("بيانات الدخول غير صحيحة."))).setNegativeButton("إلغاء",null).show();}
    String roleLabel(String role){if("customer_service".equals(role))return"خدمة العملاء";if("establishment_reviewer".equals(role))return"مراجعة المنشآت";if("offers_manager".equals(role))return"إدارة العروض";return"المدير الرئيسي";}
    void applyRolePermissions(){boolean admin=isMainAdmin();findViewById(R.id.btnAdminAddBusiness).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminAddOwner).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminAddOffer).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminStats).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminStaff).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.staffSection).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminOwners).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminRequests).setVisibility((admin||"establishment_reviewer".equals(staffRole))?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminBusinesses).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminOffers).setVisibility((admin||"offers_manager".equals(staffRole))?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminRatings).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.btnAdminComplaints).setVisibility((admin||"customer_service".equals(staffRole))?View.VISIBLE:View.GONE);findViewById(R.id.requestSection).setVisibility((admin||"establishment_reviewer".equals(staffRole))?View.VISIBLE:View.GONE);findViewById(R.id.ownerSection).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.businessSection).setVisibility(admin?View.VISIBLE:View.GONE);findViewById(R.id.offerSection).setVisibility((admin||"offers_manager".equals(staffRole))?View.VISIBLE:View.GONE);findViewById(R.id.complaintSection).setVisibility((admin||"customer_service".equals(staffRole))?View.VISIBLE:View.GONE);findViewById(R.id.ratingSection).setVisibility(admin?View.VISIBLE:View.GONE);}
    void loadRoleData(){
        if(isMainAdmin())loadAdminStats();
        else if("establishment_reviewer".equals(staffRole))loadRequests();
        else if("offers_manager".equals(staffRole))loadAdminOffers();
        else if("customer_service".equals(staffRole))loadComplaints();
    }

    void openAdminOfferForm(){
        if(!isMainAdmin()){toast("المدير الرئيسي فقط.");return;}
        db.collection("businesses").whereEqualTo("status","approved").limit(300).get().addOnSuccessListener(bs->{
            ArrayList<DocumentSnapshot> list=new ArrayList<>();for(DocumentSnapshot b:bs)list.add(b);
            if(list.isEmpty()){toast("أضف منشأة أولًا.");return;}
            String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=safe(list.get(i).getString("name"));
            Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
            new AlertDialog.Builder(this).setTitle("🎁 اختيار المنشأة للعرض").setView(sp).setPositiveButton("متابعة",(q,w)->{
                findViewById(R.id.offerForm).setTag(list.get(sp.getSelectedItemPosition()).getId());
                offerTitle.setText("");offerDesc.setText("");offerDiscount.setText("");offerStartDate="";offerEndDate="";
                findViewById(R.id.offerForm).setVisibility(View.VISIBLE);show(offersPanel);
            }).setNegativeButton("إلغاء",null).show();
        });
    }

    List<String> employeePermissions(String role){
        if("customer_service".equals(role))return Arrays.asList("complaints_read","complaints_update","complaints_close");
        if("establishment_reviewer".equals(role))return Arrays.asList("change_requests_read","change_requests_review");
        if("offers_manager".equals(role))return Arrays.asList("offers_read","offers_approve","offers_disable","offers_delete");
        return Collections.emptyList();
    }

    void manageStaff(){
        if(!isMainAdmin()){toast("المدير الرئيسي فقط.");return;}
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(12,4,12,4);
        Button add=btn("➕ إضافة موظف جديد");wrap.addView(add);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);wrap.addView(sv,new LinearLayout.LayoutParams(-1,600));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("👥 إدارة الموظفين والصلاحيات").setView(wrap).setPositiveButton("إغلاق",null).create();
        Runnable reload=()->{list.removeAllViews();db.collection("users").whereIn("role",Arrays.asList("customer_service","establishment_reviewer","offers_manager")).limit(200).get().addOnSuccessListener(ss->{if(ss.isEmpty())addText(list,"لا يوجد موظفون.");for(DocumentSnapshot d:ss){LinearLayout c=box();String role=safe(d.getString("role"));String perms=safe(String.valueOf(d.get("permissions")));c.addView(tv("👤 "+safe(d.getString("displayName"))+"\n📧 "+safe(d.getString("email"))+"\nالصلاحية: "+roleLabel(role)+"\nالحالة: "+(truth(d,"enabled")?"مفعل":"موقوف")+"\nالمهام: "+perms));Button t=btn(truth(d,"enabled")?"⛔ إيقاف الموظف":"✅ تفعيل الموظف");c.addView(t);t.setOnClickListener(v->d.getReference().update("enabled",!truth(d,"enabled")).addOnSuccessListener(x->reload.run()).addOnFailureListener(e->toast("تعذر تغيير حالة الموظف: "+safe(e.getMessage()))));list.addView(c);}}).addOnFailureListener(e->addText(list,"تعذر تحميل الموظفين: "+safe(e.getMessage())));};
        add.setOnClickListener(v->createEmployee());
        dlg.setOnShowListener(x->reload.run());dlg.show();
    }

    void createEmployee(){if(!isMainAdmin()){toast("المدير الرئيسي فقط يستطيع إنشاء الحسابات.");return;}LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);EditText nm=new EditText(this);nm.setHint("اسم الموظف");EditText em=new EditText(this);em.setHint("البريد الإلكتروني");EditText pw=new EditText(this);pw.setHint("كلمة المرور (6+ أحرف)");pw.setInputType(0x81);Spinner role=new Spinner(this);role.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"خدمة العملاء","مراجعة المنشآت","إدارة العروض"}));l.addView(nm);l.addView(em);l.addView(pw);l.addView(role);new AlertDialog.Builder(this).setTitle("إضافة حساب موظف").setView(l).setPositiveButton("إنشاء",(d,w)->{if(nm.getText().toString().trim().isEmpty()||em.getText().toString().trim().isEmpty()||pw.getText().toString().length()<6){toast("أكمل البيانات وكلمة المرور.");return;}String[]roles={"customer_service","establishment_reviewer","offers_manager"};createAuthUser(em.getText().toString().trim(),pw.getText().toString(),m->{m.put("role",roles[role.getSelectedItemPosition()]);m.put("displayName",nm.getText().toString().trim());m.put("enabled",true);m.put("permissions",employeePermissions(roles[role.getSelectedItemPosition()]));m.put("createdAt",FieldValue.serverTimestamp());},"تم إنشاء حساب الموظف.");}).setNegativeButton("إلغاء",null).show();}

    void createOwnerAccount(){if(!isMainAdmin()){toast("المدير الرئيسي فقط.");return;}db.collection("businesses").whereEqualTo("status","approved").limit(300).get().addOnSuccessListener(bs->{ArrayList<DocumentSnapshot> list=new ArrayList<>();for(DocumentSnapshot b:bs)list.add(b);if(list.isEmpty()){toast("أضف منشأة أولًا ثم أنشئ حساب صاحبها.");return;}LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);EditText nm=new EditText(this);nm.setHint("اسم صاحب المنشأة");EditText em=new EditText(this);em.setHint("البريد الإلكتروني");EditText ph=new EditText(this);ph.setHint("رقم الهاتف");EditText pw=new EditText(this);pw.setHint("كلمة المرور (6+ أحرف)");pw.setInputType(0x81);Spinner sp=new Spinner(this);String[]names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=safe(list.get(i).getString("name"));sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));l.addView(nm);l.addView(em);l.addView(ph);l.addView(pw);l.addView(sp);new AlertDialog.Builder(this).setTitle("👤 إنشاء حساب صاحب منشأة").setView(l).setPositiveButton("إنشاء",(d,w)->{if(nm.getText().toString().trim().isEmpty()||em.getText().toString().trim().isEmpty()||pw.getText().toString().length()<6){toast("أكمل البيانات.");return;}DocumentSnapshot b=list.get(sp.getSelectedItemPosition());String bid=b.getId();createAuthUser(em.getText().toString().trim(),pw.getText().toString(),m->{m.put("role","owner");m.put("displayName",nm.getText().toString().trim());m.put("email",em.getText().toString().trim());m.put("phone",ph.getText().toString().trim());m.put("businessName",safe(b.getString("name")));m.put("businessId",bid);m.put("enabled",true);m.put("permissions",Arrays.asList("owner_profile_edit_request","owner_offer_create","owner_requests_view"));m.put("createdAt",FieldValue.serverTimestamp());},"تم إنشاء حساب صاحب المنشأة وربطه.");}).setNegativeButton("إلغاء",null).show();});}
    interface UserMapBuilder{void build(Map<String,Object>m);}
    void createAuthUser(String email,String password,UserMapBuilder builder,String ok){
        if(!isMainAdmin() || auth==null || auth.getCurrentUser()==null || auth.getCurrentUser().isAnonymous()){
            toast("⛔ يجب أن تكون داخل حساب المدير الرئيسي لإنشاء الحساب.");return;
        }
        final String cleanEmail=email.trim().toLowerCase(Locale.ROOT);
        FirebaseApp secondary;
        try{secondary=FirebaseApp.getInstance("userCreator");}
        catch(Exception e){secondary=FirebaseApp.initializeApp(this,FirebaseApp.getInstance().getOptions(),"userCreator");}
        FirebaseAuth sa=FirebaseAuth.getInstance(secondary);
        sa.createUserWithEmailAndPassword(cleanEmail,password).addOnSuccessListener(r->{
            FirebaseUser created=r.getUser();
            if(created==null){toast("تعذر إنشاء حساب الدخول.");return;}
            Map<String,Object> m=new HashMap<>(); builder.build(m);
            String uid=created.getUid();
            // حفظ وثيقة الصلاحيات يتم بجلسة المدير الأساسية، وليس بجلسة الحساب الجديد.
            db.collection("users").document(uid).set(m).addOnSuccessListener(x->{
                Object bid=m.get("businessId"); Object role=m.get("role");
                Task<Void> linkTask=Tasks.forResult(null);
                if("owner".equals(role)&&bid!=null&&!String.valueOf(bid).isEmpty()){
                    linkTask=db.collection("businesses").document(String.valueOf(bid)).update("ownerUid",uid,"updatedAt",FieldValue.serverTimestamp());
                }
                linkTask.addOnSuccessListener(v->{
                    sa.signOut();try{secondary.delete();}catch(Exception ignored){}
                    toast("✅ "+ok);
                    if("owner".equals(role))loadOwners();
                }).addOnFailureListener(e->{
                    // لا نترك حسابًا ناقص الربط. نحاول حذف وثيقة المستخدم أيضًا.
                    db.collection("users").document(uid).delete().addOnCompleteListener(q->{
                        created.delete().addOnCompleteListener(z->{sa.signOut();try{secondary.delete();}catch(Exception ignored){}
                            toast("❌ تعذر ربط الحساب بالمنشأة: "+safe(e.getMessage()));});
                    });
                });
            }).addOnFailureListener(e->{
                created.delete().addOnCompleteListener(q->{sa.signOut();try{secondary.delete();}catch(Exception ignored){}
                    String msg=safe(e.getMessage());
                    if(msg.contains("PERMISSION_DENIED"))msg="صلاحيات Firestore تمنع إنشاء الحساب. تأكد أن قواعد V24 منشورة وأن حساب المدير مفعل.";
                    toast("❌ تعذر حفظ الصلاحيات: "+msg);
                });
            });
        }).addOnFailureListener(e->{
            String msg=safe(e.getMessage());
            if(msg.contains("already in use"))msg="البريد الإلكتروني مستخدم بالفعل.";
            toast("❌ تعذر إنشاء الحساب: "+msg);
        });
    }

    void loadAdminStats(){if(!isMainAdmin()){toast("الإحصائيات للمدير الرئيسي فقط.");return;}String[]cols={"businesses","offers","ratings","complaints","users","businessViews","callClicks","whatsappClicks","mapClicks","favoriteClicks"};StringBuilder out=new StringBuilder("📊 مركز الأرقام\n");final int[]done={0};for(String c:cols){db.collection(c).get().addOnSuccessListener(s->{out.append("\n• ").append(c).append(": ").append(s.size());done[0]++;if(done[0]==cols.length)statsText.setText(out.toString());}).addOnFailureListener(e->{done[0]++;if(done[0]==cols.length)statsText.setText(out+"\n• بعض الأرقام غير متاحة");});}}
    void loadRequests(){
        requestList.removeAllViews();
        if(!canManageRequests()){addText(requestList,"ليس لديك صلاحية عرض الطلبات.");return;}
        db.collection("changeRequests").whereIn("status",Arrays.asList("pending","reviewed")).limit(100).get().addOnSuccessListener(s->{
            if(s.isEmpty()){addText(requestList,"لا توجد طلبات معلقة.");return;}
            for(DocumentSnapshot d:s){
                Map<String,Object> ch=(Map<String,Object>)d.get("changes");
                String nm=ch==null?"":safe((String)ch.get("name"));
                String status=safe(d.getString("status"));
                LinearLayout c=box();
                c.addView(tv("🕐 طلب تعديل\n🏪 "+nm+"\nالحالة: "+status+"\nID: "+safe(d.getId())));
                LinearLayout a=new LinearLayout(this);
                if(isMainAdmin()){
                    Button ok=btn("reviewed".equals(status)?"✅ اعتماد ونشر":"👀 مراجعة/نشر");
                    Button no=btn("❌ رفض"); a.addView(ok);a.addView(no);
                    ok.setOnClickListener(v->approveRequest(d));
                    no.setOnClickListener(v->rejectRequest(d));
                }else if("pending".equals(status)){
                    Button ok=btn("✅ تمت المراجعة"); a.addView(ok);ok.setOnClickListener(v->approveRequest(d));
                }
                c.addView(a); requestList.addView(c);
            }
        }).addOnFailureListener(e->addText(requestList,"تعذر تحميل الطلبات: "+safe(e.getMessage())));
    }

    void approveRequest(DocumentSnapshot r){
        if(!canManageRequests()){toast("ليس لديك صلاحية مراجعة الطلبات.");return;}
        Map<String,Object> ch=(Map<String,Object>)r.get("changes");
        String bid=safe(r.getString("businessId"));
        if(ch==null||bid.isEmpty()){toast("طلب التعديل ناقص البيانات.");return;}
        if(!isMainAdmin()){
            Map<String,Object> review=new HashMap<>();
            review.put("status","reviewed");
            review.put("reviewedBy",auth.getCurrentUser()==null?"":auth.getCurrentUser().getUid());
            review.put("reviewedAt",FieldValue.serverTimestamp());
            r.getReference().update(review).addOnSuccessListener(x->{adminStatus.setText("✅ تمت مراجعة الطلب وإحالته للمدير النهائي.");loadRequests();}).addOnFailureListener(e->toast("تعذر حفظ حالة المراجعة: "+safe(e.getMessage())));
            return;
        }
        db.collection("businesses").document(bid).set(ch,SetOptions.merge()).addOnSuccessListener(x->r.getReference().update("status","approved","reviewedBy",auth.getCurrentUser()==null?"":auth.getCurrentUser().getUid(),"reviewedAt",FieldValue.serverTimestamp()).addOnSuccessListener(y->{adminStatus.setText("✅ تمت الموافقة ونشر التعديل.");loadRequests();}).addOnFailureListener(e->toast("تم تعديل المنشأة لكن تعذر تحديث حالة الطلب: "+safe(e.getMessage())))).addOnFailureListener(e->toast("تعذر نشر التعديل: "+safe(e.getMessage())));
    }
    void rejectRequest(DocumentSnapshot r){if(!isMainAdmin()){toast("رفض الطلب النهائي للمدير الرئيسي.");return;}r.getReference().update("status","rejected","reviewedAt",FieldValue.serverTimestamp()).addOnSuccessListener(x->{adminStatus.setText("تم رفض الطلب");loadRequests();});}
    void loadOwners(){ownerList.removeAllViews();db.collection("users").whereEqualTo("role","owner").limit(200).get().addOnSuccessListener(s->{if(s.isEmpty())addText(ownerList,"لا يوجد أصحاب منشآت.");for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("👤 "+safe(d.getString("displayName"))+"\n📧 "+safe(d.getString("email"))+"\n📞 "+safe(d.getString("phone"))+"\n🏪 "+safe(d.getString("businessName"))));Button b=btn(truth(d,"enabled")?"⛔ إيقاف الحساب":"✅ تفعيل الحساب");c.addView(b);b.setOnClickListener(v->d.getReference().update("enabled",!truth(d,"enabled")).addOnSuccessListener(x->loadOwners()));ownerList.addView(c);}});}
    void loadAdminBusinesses(){adminBusinessList.removeAllViews();db.collection("businesses").limit(300).get().addOnSuccessListener(s->{if(s.isEmpty())addText(adminBusinessList,"لا توجد منشآت.");for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("🏪 "+safe(d.getString("name"))+"\nالحالة: "+safe(d.getString("status"))+" | مفعل: "+truth(d,"active")+" | مميز: "+truth(d,"featured")));LinearLayout a=new LinearLayout(this);Button edit=btn("✏️ تعديل"),toggle=btn(truth(d,"active")?"إخفاء":"إظهار"),feat=btn(truth(d,"featured")?"إلغاء المميز":"⭐ تمييز"),del=btn("🗑️ حذف");a.addView(edit);a.addView(toggle);a.addView(feat);a.addView(del);c.addView(a);edit.setOnClickListener(v->{editingBusinessId=d.getId();fillBusiness(d);show(addPanel);});toggle.setOnClickListener(v->d.getReference().update("active",!truth(d,"active"),"updatedAt",FieldValue.serverTimestamp()).addOnSuccessListener(x->loadAdminBusinesses()));feat.setOnClickListener(v->d.getReference().update("featured",!truth(d,"featured"),"updatedAt",FieldValue.serverTimestamp()).addOnSuccessListener(x->loadAdminBusinesses()));del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف المنشأة").setMessage("سيتم حذف سجل المنشأة من Firestore. هل تريد المتابعة؟").setPositiveButton("حذف",(q,w)->d.getReference().delete().addOnSuccessListener(x->loadAdminBusinesses())).setNegativeButton("إلغاء",null).show());adminBusinessList.addView(c);}});}
    void loadAdminOffers(){adminOfferList.removeAllViews();db.collection("offers").limit(300).get().addOnSuccessListener(s->{if(s.isEmpty())addText(adminOfferList,"لا توجد عروض.");for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("🎁 "+safe(d.getString("title"))+"\nالحالة: "+safe(d.getString("status"))+" | فعال: "+truth(d,"active")+"\n🏪 "+safe(d.getString("businessId"))));LinearLayout a=new LinearLayout(this);Button ok=btn("✅ اعتماد/تفعيل"),no=btn("❌ إيقاف"),del=btn("🗑️ حذف");a.addView(ok);a.addView(no);a.addView(del);c.addView(a);ok.setOnClickListener(v->d.getReference().update("active",true,"status","approved").addOnSuccessListener(x->loadAdminOffers()));no.setOnClickListener(v->d.getReference().update("active",false,"status","rejected").addOnSuccessListener(x->loadAdminOffers()));del.setOnClickListener(v->d.getReference().delete().addOnSuccessListener(x->loadAdminOffers()));adminOfferList.addView(c);}});}
    void loadComplaints(){adminComplaintList.removeAllViews();db.collection("complaints").limit(300).get().addOnSuccessListener(s->{if(s.isEmpty())addText(adminComplaintList,"لا توجد شكاوى.");for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("📣 "+safe(d.getString("text"))+"\nالحالة: "+safe(d.getString("status"))));Button b=btn("إغلاق");c.addView(b);b.setOnClickListener(v->d.getReference().update("status","closed","updatedAt",FieldValue.serverTimestamp()).addOnSuccessListener(x->loadComplaints()));adminComplaintList.addView(c);}});}
    void loadRatings(){adminRatingList.removeAllViews();db.collection("ratings").limit(300).get().addOnSuccessListener(s->{if(s.isEmpty())addText(adminRatingList,"لا توجد تقييمات.");for(DocumentSnapshot d:s){Long stars=d.getLong("stars");LinearLayout c=box();c.addView(tv("⭐ "+(stars==null?"":stars)+"\n"+safe(d.getString("text"))+"\nمنشأة: "+safe(d.getString("businessId"))+"\nالحالة: "+safe(d.getString("status"))));Button b=btn("pending".equals(d.getString("status"))?"✅ اعتماد":"🗑️ حذف");c.addView(b);b.setOnClickListener(v->{if("pending".equals(d.getString("status")))approveRating(d);else d.getReference().delete().addOnSuccessListener(x->loadRatings());});adminRatingList.addView(c);}});}
    void approveRating(DocumentSnapshot d){if(!isMainAdmin())return;d.getReference().update("status","approved").addOnSuccessListener(x->{String bid=d.getString("businessId");recalcRating(bid);});}
    void recalcRating(String bid){if(bid==null)return;db.collection("ratings").whereEqualTo("businessId",bid).whereEqualTo("status","approved").get().addOnSuccessListener(s->{double sum=0;int n=0;for(DocumentSnapshot r:s){Long st=r.getLong("stars");if(st!=null){sum+=st;n++;}}db.collection("businesses").document(bid).update("ratingAvg",n==0?0:sum/n,"ratingCount",n).addOnCompleteListener(q->loadRatings());});}
    void showRatingDialog(String bid){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"5","4","3","2","1"}));EditText tx=new EditText(this);tx.setHint("رأيك (اختياري)");l.addView(sp);l.addView(tx);new AlertDialog.Builder(this).setTitle("تقييم المنشأة").setView(l).setPositiveButton("إرسال",(d,w)->{FirebaseUser u=auth.getCurrentUser();if(u==null)return;String rid=u.getUid()+"_"+bid;Map<String,Object>m=new HashMap<>();m.put("businessId",bid);m.put("stars",Integer.parseInt(sp.getSelectedItem().toString()));m.put("text",tx.getText().toString().trim());m.put("status","pending");m.put("uid",u.getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection("ratings").document(rid).set(m).addOnSuccessListener(x->toast("تم إرسال التقييم للمراجعة"));}).setNegativeButton("إلغاء",null).show();}
    void sendComplaint(){String t=complaintText.getText().toString().trim();if(t.isEmpty()){serviceStatus.setText("اكتب الرسالة أولًا.");return;}Map<String,Object>m=new HashMap<>();m.put("text",t);m.put("status","open");m.put("type",complaintType==null||complaintType.getSelectedItem()==null?"شكوى":complaintType.getSelectedItem().toString());m.put("createdAt",FieldValue.serverTimestamp());m.put("uid",auth.getCurrentUser()==null?"":auth.getCurrentUser().getUid());db.collection("complaints").add(m).addOnSuccessListener(x->{serviceStatus.setText("✅ تم إرسال الرسالة لخدمة العملاء.");complaintText.setText("");}).addOnFailureListener(e->serviceStatus.setText("تعذر إرسال الرسالة."));}

    void takePhoto(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAM);return;}
        try{
            restoreAddPanel=true; cameraPending=true;
            File dir=new File(getExternalFilesDir("Pictures"),"shops");if(!dir.exists())dir.mkdirs();
            photoFile=new File(dir,"shop_"+System.currentTimeMillis()+".jpg");
            photoUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",photoFile);
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setClipData(ClipData.newRawUri("output",photoUri));
            startActivityForResult(i,100);
        }catch(Exception e){cameraPending=false;restoreAddPanel=true;photoUri=null;photoFile=null;show(addPanel);addStatus.setText("تعذر فتح الكاميرا. حاول مرة أخرى.");}
    }
    void pickImages(){restoreAddPanel=true;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,GALLERY);}
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==100){
            cameraPending=false; restoreAddPanel=true;
            boolean captured=(c==Activity.RESULT_OK)||(photoFile!=null&&photoFile.exists()&&photoFile.length()>1000);
            if(captured&&photoUri!=null){
                Uri capturedUri=photoUri;
                if(!imageUris.contains(capturedUri))imageUris.add(capturedUri);
                // لا نغلق شاشة إضافة المنشأة ولا ننتقل للرئيسية بعد الرجوع من تطبيق الكاميرا.
                show(addPanel);
                renderThumbs();
                runOcr(capturedUri);
                photoUri=null; photoFile=null; cameraPending=false; restoreAddPanel=true;
                addStatus.setText("✅ تمت إضافة الصورة. يمكنك حذفها أو إضافة صورة أخرى قبل الحفظ.");
            }else{show(addPanel);cameraPending=false;addStatus.setText("لم يتم حفظ الصورة. حاول التصوير مرة أخرى.");}
            return;
        }
        if(r==GALLERY){
            restoreAddPanel=true;
            if(c==Activity.RESULT_OK&&d!=null){if(d.getClipData()!=null)for(int i=0;i<d.getClipData().getItemCount();i++)addGalleryUri(d.getClipData().getItemAt(i).getUri());else if(d.getData()!=null)addGalleryUri(d.getData());renderThumbs();}
            show(addPanel);
        }
    }
    void addGalleryUri(Uri u){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(!imageUris.contains(u))imageUris.add(u);}
    void clearAllImages(){imageUris.clear();renderThumbs();addStatus.setText("🗑️ تم حذف كل الصور من قائمة الحفظ.");}
    void renderThumbs(){
        thumbs.removeAllViews();
        for(int i=0;i<imageUris.size();i++){
            final int idx=i;
            LinearLayout w=new LinearLayout(this);w.setOrientation(LinearLayout.VERTICAL);w.setPadding(4,4,4,4);w.setGravity(Gravity.CENTER);w.setBackgroundResource(R.drawable.bg_card);
            ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);
            try{Glide.with(this).load(imageUris.get(i)).centerCrop().into(im);}catch(Exception ex){im.setImageURI(imageUris.get(i));}
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(102),dp(76));w.addView(im,ip);
            Button del=btn("✕ حذف الصورة");del.setTextSize(11);del.setAllCaps(false);del.setTextColor(Color.WHITE);del.setBackgroundResource(R.drawable.bg_primary);
            del.setOnClickListener(v->{
                if(idx<imageUris.size()){
                    imageUris.remove(idx);renderThumbs();
                    addStatus.setText("🗑️ تم حذف الصورة من قائمة الحفظ. الصور الأخرى ما زالت موجودة.");
                }
            });
            w.addView(del,new LinearLayout.LayoutParams(dp(102),dp(34)));
            w.setOnClickListener(v->previewImage(imageUris.get(idx)));
            LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(dp(110),dp(120));wp.setMargins(0,0,dp(8),0);thumbs.addView(w,wp);
        }
        imageCount.setText("🖼️ عدد الصور الجديدة: "+imageUris.size()+"   •   اضغط على أي صورة للمعاينة");
    }

    int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    void previewImage(Uri u){
        ImageView iv=new ImageView(this);iv.setBackgroundColor(Color.BLACK);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try{Glide.with(this).load(u).into(iv);}catch(Exception ignored){iv.setImageURI(u);}
        new AlertDialog.Builder(this).setTitle("🖼️ معاينة الصورة").setView(iv).setPositiveButton("إغلاق",null).show();
    }
    void runOcr(Uri u){try{InputImage img=InputImage.fromFilePath(this,u);TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img).addOnSuccessListener(res->{String t=res.getText();if(name.getText().length()==0&&!t.trim().isEmpty())name.setText(t.split("\\n")[0]);addStatus.setText("تمت محاولة قراءة الاسم من الصورة؛ راجعه قبل الحفظ.");});}catch(Exception ignored){}}
    void getLocation(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOC);return;}fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,null).addOnSuccessListener(l->{if(l!=null){lat=l.getLatitude();lng=l.getLongitude();location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));}}).addOnFailureListener(e->addStatus.setText("تعذر تحديد الموقع."));}
    @Override protected void onResume(){super.onResume();}

    void installBackHandler(){
        getOnBackPressedDispatcher().addCallback(this,new OnBackPressedCallback(true){
            @Override public void handleOnBackPressed(){
                if(adminPanel.getVisibility()==View.VISIBLE){
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("العودة من لوحة المدير")
                        .setMessage("هل تريد الخروج من لوحة المدير والعودة إلى الصفحة الرئيسية العادية؟")
                        .setNegativeButton("إلغاء",null)
                        .setPositiveButton("العودة للرئيسية",(d,w)->showHome())
                        .show();
                    return;
                }
                if(homePanel.getVisibility()==View.VISIBLE){
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("الخروج من نجم ديرب")
                        .setMessage("هل تريد الخروج من التطبيق؟")
                        .setNegativeButton("إلغاء",null)
                        .setPositiveButton("خروج",(d,w)->finish())
                        .show();
                } else {
                    showHome();
                }
            }
        });
    }

    void clearForm(){editingBusinessId="";name.setText("");phone.setText("");whatsapp.setText("");facebook.setText("");address.setText("");description.setText("");hours.setText("");services.setText("");website.setText("");lat=0;lng=0;location.setText("📍 لم يتم تحديد الموقع");imageUris.clear();renderThumbs();addStatus.setText("");}
    void fillBusiness(DocumentSnapshot b){name.setText(safe(b.getString("name")));phone.setText(safe(b.getString("phone")));whatsapp.setText(safe(b.getString("whatsapp")));facebook.setText(safe(b.getString("facebook")));address.setText(safe(b.getString("address")));description.setText(safe(b.getString("description")));hours.setText(safe(b.getString("hours")));services.setText(safe(b.getString("services")));website.setText(safe(b.getString("website")));lat=num(b,"lat");lng=num(b,"lng");location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));imageUris.clear();renderThumbs();}
    void openMap(DocumentSnapshot d){Double a=d.getDouble("lat"),b=d.getDouble("lng");if(a==null||b==null){toast("موقع المنشأة غير متاح.");return;}navigateToMap(a,b,safe(d.getString("name")));}
    void navigateToMap(double a,double b,String label){Uri nav=Uri.parse("https://www.google.com/maps/dir/?api=1&destination="+a+","+b);Intent i=new Intent(Intent.ACTION_VIEW,nav);try{startActivity(i);}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:"+a+","+b+"?q="+a+","+b+"("+Uri.encode(label==null?"الموقع":label)+")")));}}
    void openMapPicker(){
        try{
            Configuration.getInstance().load(this,getSharedPreferences("osmdroid",MODE_PRIVATE));
            Configuration.getInstance().setUserAgentValue("NegmDiarb/1.0");
        }catch(Exception ignored){}
        final LinearLayout wrap=new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(6),dp(6),dp(6),dp(2));

        final TextView tip=tv("اضغط على الخريطة لاختيار الموقع، أو حرّك العلامة 📍\\nالمكان المحدد سيُحفظ مباشرة في بيانات المنشأة.");
        tip.setTextSize(14); tip.setTextColor(Color.rgb(23,32,51)); wrap.addView(tip);

        final MapView map=new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setBuiltInZoomControls(true);
        map.setMultiTouchControls(true);
        map.setUseDataConnection(true);
        map.setFlingEnabled(true);
        wrap.addView(map,new LinearLayout.LayoutParams(-1,dp(360)));

        final TextView coords=tv(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));
        coords.setTextSize(14); coords.setTextColor(Color.rgb(23,32,51)); wrap.addView(coords);

        final LinearLayout actionRow=new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        Button myLoc=btn("📍 موقعي الحالي");
        Button accept=btn("✅ اعتماد الموقع");
        actionRow.addView(myLoc,new LinearLayout.LayoutParams(0,dp(48),1));
        actionRow.addView(accept,new LinearLayout.LayoutParams(0,dp(48),1));
        wrap.addView(actionRow);

        double startLat=(lat!=0)?lat:30.710099;
        double startLng=(lng!=0)?lng:31.415552;
        final GeoPoint startPoint=new GeoPoint(startLat,startLng);
        map.getController().setZoom(16.5);
        map.getController().setCenter(startPoint);

        final Marker marker=new Marker(map);
        marker.setPosition(startPoint);
        marker.setDraggable(true);
        marker.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM);
        marker.setTitle("موقع المنشأة");
        map.getOverlays().add(marker);

        MapEventsOverlay events=new MapEventsOverlay(new MapEventsReceiver(){
            @Override public boolean singleTapConfirmedHelper(GeoPoint p){
                marker.setPosition(p); updatePickedLocation(p,coords); map.invalidate(); return true;
            }
            @Override public boolean longPressHelper(GeoPoint p){
                marker.setPosition(p); updatePickedLocation(p,coords); map.invalidate(); return true;
            }
        });
        map.getOverlays().add(events);

        marker.setOnMarkerDragListener(new Marker.OnMarkerDragListener(){
            public void onMarkerDragStart(Marker m){}
            public void onMarkerDrag(Marker m){updatePickedLocation(m.getPosition(),coords);}
            public void onMarkerDragEnd(Marker m){updatePickedLocation(m.getPosition(),coords);map.invalidate();}
        });

        final AlertDialog dlg=new AlertDialog.Builder(this)
                .setTitle("🗺️ اختيار موقع المنشأة")
                .setView(wrap)
                .setNegativeButton("إلغاء",null)
                .create();

        accept.setOnClickListener(v->{
            if(marker.getPosition()!=null){
                updatePickedLocation(marker.getPosition(),coords);
                dlg.dismiss();
                addStatus.setText("✅ تم اعتماد الموقع المحدد من الخريطة.");
            }
        });

        myLoc.setOnClickListener(v->{
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOC);
                return;
            }
            fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,null)
                .addOnSuccessListener(l->{
                    if(l!=null){
                        GeoPoint p=new GeoPoint(l.getLatitude(),l.getLongitude());
                        marker.setPosition(p);
                        map.getController().animateTo(p);
                        map.getController().setZoom(17.5);
                        updatePickedLocation(p,coords);
                        map.invalidate();
                    }else toast("تعذر تحديد موقعك الآن.");
                })
                .addOnFailureListener(e->toast("تعذر تحديد موقعك الآن."));
        });

        dlg.setOnShowListener(x->{
            try{
                map.onResume();
                map.invalidate();
                if(map.getWidth()>0)map.getController().setCenter(startPoint);
            }catch(Exception ignored){}
            if(dlg.getWindow()!=null)
                dlg.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.97),
                        (int)(getResources().getDisplayMetrics().heightPixels*.90));
        });
        dlg.setOnDismissListener(x->{try{map.onPause();map.onDetach();}catch(Exception ignored){}});
        dlg.show();
    }

    void updatePickedLocation(GeoPoint p,TextView coords){
        if(p==null)return;lat=p.getLatitude();lng=p.getLongitude();coords.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));addStatus.setText("✅ الموقع جاهز للحفظ.");
    }
    void call(String p){if(p==null||p.isEmpty()){toast("لا يوجد رقم اتصال.");return;}startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+p)));}
    void wa(String bid,String p){if(p==null||p.isEmpty()){toast("لا يوجد رقم واتساب لهذه المنشأة.");return;}String n=normalizeEgyptPhone(p).replace("+","");if(n.length()<10){toast("رقم واتساب غير صالح.");return;}String msg="مرحبًا، وصلت إليكم عن طريق تطبيق نجم ديرب.";try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+n+"?text="+Uri.encode(msg))));}catch(Exception e){toast("تعذر فتح واتساب.");}}
    String normalizeEgyptPhone(String p){if(p==null)return"";String x=p.trim().replaceAll("[^0-9+]","");if(x.startsWith("+20"))return x;if(x.startsWith("20"))return"+"+x;if(x.startsWith("0"))return"+20"+x.substring(1);return x;}
    LinearLayout box(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(14,14,14,14);l.setBackgroundResource(R.drawable.bg_card);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,10);l.setLayoutParams(p);return l;}
    TextView tv(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setTextColor(android.graphics.Color.rgb(23,32,51));t.setPadding(6,6,6,6);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setMinHeight(0);b.setPadding(4,0,4,0);b.setBackgroundResource(R.drawable.bg_card);return b;}
    void addText(LinearLayout l,String s){l.addView(tv(s));}
}
