package com.negmdiarb.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.*;

public class MainActivity extends ComponentActivity {
    ImageView photo;
    EditText name, phone, address, description;
    TextView location, status;
    Spinner category;
    LinearLayout savedContainer;
    Uri photoUri;
    FusedLocationProviderClient fused;
    double lat = 0, lng = 0;
    final int CAM = 10, LOC = 11;
    final String PREFS = "negm_diarb", KEY = "businesses";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        photo = findViewById(R.id.photo);
        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        address = findViewById(R.id.address);
        description = findViewById(R.id.description);
        location = findViewById(R.id.location);
        status = findViewById(R.id.status);
        category = findViewById(R.id.category);
        savedContainer = findViewById(R.id.savedContainer);
        category.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"مطاعم", "محلات", "عيادات", "أخرى"}));
        fused = LocationServices.getFusedLocationProviderClient(this);
        findViewById(R.id.btnPhoto).setOnClickListener(v -> takePhoto());
        findViewById(R.id.btnLocation).setOnClickListener(v -> getLocation());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        loadSaved();
    }

    void takePhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAM); return;
        }
        File dir = new File(getExternalFilesDir("Pictures"), "shops"); dir.mkdirs();
        File f = new File(dir, "shop_" + System.currentTimeMillis() + ".jpg");
        photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i, 100);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == 100 && c == Activity.RESULT_OK) { photo.setImageURI(photoUri); runOcr(); }
    }

    void runOcr() {
        try {
            InputImage img = InputImage.fromFilePath(this, photoUri);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)
                .addOnSuccessListener(res -> {
                    String t = res.getText();
                    if (name.getText().length() == 0 && !t.trim().isEmpty()) name.setText(t.split("\\n")[0]);
                    status.setText("تمت محاولة قراءة البيانات؛ راجعها قبل الحفظ.");
                })
                .addOnFailureListener(e -> status.setText("تم التقاط الصورة. أدخل البيانات يدويًا إذا لزم."));
        } catch (Exception e) { status.setText("تم التقاط الصورة."); }
    }

    void getLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOC); return;
        }
        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener(l -> {
            if (l != null) { lat = l.getLatitude(); lng = l.getLongitude(); location.setText(String.format(Locale.US, "الموقع: %.6f, %.6f", lat, lng)); }
            else status.setText("لم يتم الحصول على الموقع؛ جرّب مرة أخرى.");
        });
    }

    void save() {
        String n = name.getText().toString().trim();
        if (n.isEmpty()) { name.setError("اكتب اسم المنشأة"); return; }
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY, "[]"));
            JSONObject o = new JSONObject();
            o.put("id", System.currentTimeMillis());
            o.put("name", n);
            o.put("phone", phone.getText().toString().trim());
            o.put("address", address.getText().toString().trim());
            o.put("description", description.getText().toString().trim());
            o.put("category", category.getSelectedItem().toString());
            o.put("lat", lat); o.put("lng", lng);
            o.put("image", photoUri == null ? "" : photoUri.toString());
            arr.put(o);
            sp.edit().putString(KEY, arr.toString()).apply();
            status.setText("✅ تم حفظ المنشأة على الهاتف.");
            Toast.makeText(this, "تم الحفظ بنجاح", Toast.LENGTH_SHORT).show();
            loadSaved();
        } catch (Exception e) { status.setText("حدث خطأ أثناء الحفظ."); }
    }

    void loadSaved() {
        savedContainer.removeAllViews();
        try {
            JSONArray arr = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY, "[]"));
            if (arr.length() == 0) { TextView empty = new TextView(this); empty.setText("لا توجد منشآت محفوظة حتى الآن."); empty.setPadding(0,12,0,12); savedContainer.addView(empty); return; }
            for (int i = arr.length()-1; i >= 0; i--) addSavedCard(arr.getJSONObject(i), i);
        } catch (Exception e) { }
    }

    void addSavedCard(JSONObject o, int index) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(16,16,16,16);
        TextView title = new TextView(this); title.setText("🏪 " + o.optString("name")); title.setTextSize(19); title.setTextDirection(View.TEXT_DIRECTION_RTL); title.setPadding(0,0,0,6);
        TextView info = new TextView(this); info.setText(o.optString("category") + "\n" + o.optString("address") + "\n" + o.optString("phone")); info.setTextSize(15); info.setTextDirection(View.TEXT_DIRECTION_RTL);
        Button del = new Button(this); del.setText("حذف");
        del.setOnClickListener(v -> deleteAt(index));
        card.addView(title); card.addView(info); card.addView(del);
        savedContainer.addView(card);
        View divider = new View(this); divider.setLayoutParams(new LinearLayout.LayoutParams(-1, 2)); savedContainer.addView(divider);
    }

    void deleteAt(int index) {
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY, "[]"));
            JSONArray out = new JSONArray();
            for (int i=0;i<arr.length();i++) if (i != index) out.put(arr.getJSONObject(i));
            sp.edit().putString(KEY, out.toString()).apply(); loadSaved();
        } catch (Exception e) { }
    }
}
