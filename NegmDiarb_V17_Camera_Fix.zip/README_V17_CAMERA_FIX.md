# Negm Diarb V17 — Camera Fix

- Version code 17; keeps applicationId `com.negmdiarb.app`.
- Fixes the Add Business camera flow so returning from the camera keeps the Add Business screen open.
- Restores the Add Business screen, selected images, camera URI/file, location and edit state if Android recreates the Activity while the camera is open.
- Keeps image preview, delete-before-save, and multiple-image selection.
- Keeps Firebase, admin authorization, map picker, and stable signing workflow.
