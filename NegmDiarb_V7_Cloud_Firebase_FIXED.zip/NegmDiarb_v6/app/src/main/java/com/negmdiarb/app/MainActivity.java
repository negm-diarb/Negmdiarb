package com.negmdiarb.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.provider.MediaStore;
import android.app.AlertDialog;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.bumptech.glide.Glide;
import com.google.android.gms.location.*;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.util.*;

public class MainActivity extends ComponentActivity {
    LinearLayout root, homePanel, addPanel, loginPanel, registerPanel, ownerPanel, adminPanel, offersPanel, servicePanel, businessList, requestList, ownerList, adminBusinessList, adminOfferList, adminComplaintList, adminRatingList, thumbs;
    EditText name, phone, whatsapp, address, description, search, loginPhone, loginPassword, regBusiness, regPhone, regPassword, offerTitle, offerDesc, offerDiscount, complaintText;
    Spinner category, searchCategory;
    TextView addStatus, loginStatus, regStatus, ownerInfo, homeStatus, imageCount, location, offerStatus, serviceStatus, adminStatus;
    Uri photoUri; final ArrayList<Uri> imageUris=new ArrayList<>();
    FusedLocationProviderClient fused; FirebaseAuth auth; FirebaseFirestore db; FirebaseStorage storage;
    double lat=0,lng=0; String editingBusinessId=""; final int CAM=10,LOC=11,GALLERY=12;
    boolean adminMode=false;

    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);bind();initFirebase();setup();showHome();}
    void bind(){
        root=findViewById(R.id.root); homePanel=findViewById(R.id.homePanel); addPanel=findViewById(R.id.addPanel); loginPanel=findViewById(R.id.loginPanel); registerPanel=findViewById(R.id.registerPanel); ownerPanel=findViewById(R.id.ownerPanel); adminPanel=findViewById(R.id.adminPanel); offersPanel=findViewById(R.id.offersPanel); servicePanel=findViewById(R.id.servicePanel);
        businessList=findViewById(R.id.businessList); requestList=findViewById(R.id.requestList); ownerList=findViewById(R.id.ownerList); adminBusinessList=findViewById(R.id.adminBusinessList); adminOfferList=findViewById(R.id.adminOfferList); adminComplaintList=findViewById(R.id.adminComplaintList); adminRatingList=findViewById(R.id.adminRatingList); thumbs=findViewById(R.id.thumbs);
        name=findViewById(R.id.name);phone=findViewById(R.id.phone);whatsapp=findViewById(R.id.whatsapp);address=findViewById(R.id.address);description=findViewById(R.id.description);search=findViewById(R.id.search);loginPhone=findViewById(R.id.loginPhone);loginPassword=findViewById(R.id.loginPassword);regBusiness=findViewById(R.id.regBusiness);regPhone=findViewById(R.id.regPhone);regPassword=findViewById(R.id.regPassword);offerTitle=findViewById(R.id.offerTitle);offerDesc=findViewById(R.id.offerDesc);offerDiscount=findViewById(R.id.offerDiscount);complaintText=findViewById(R.id.complaintText);
        category=findViewById(R.id.category);searchCategory=findViewById(R.id.searchCategory);
        addStatus=findViewById(R.id.addStatus);loginStatus=findViewById(R.id.loginStatus);regStatus=findViewById(R.id.regStatus);ownerInfo=findViewById(R.id.ownerInfo);homeStatus=findViewById(R.id.homeStatus);imageCount=findViewById(R.id.imageCount);location=findViewById(R.id.location);offerStatus=findViewById(R.id.offerStatus);serviceStatus=findViewById(R.id.serviceStatus);adminStatus=findViewById(R.id.adminStatus);
    }
    void initFirebase(){auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();storage=FirebaseStorage.getInstance();fused=LocationServices.getFusedLocationProviderClient(this);if(auth.getCurrentUser()==null)auth.signInAnonymously().addOnCompleteListener(t->loadBusinesses());else loadBusinesses();}
    String[] cats={"الكل","مطاعم","محلات","عيادات","صيدليات","خدمات","ملابس","إلكترونيات","مقاهي","مخابز","أخرى"};
    void setup(){
        category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Arrays.copyOfRange(cats,1,cats.length)));
        searchCategory.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));
        findViewById(R.id.btnSearch).setOnClickListener(v->loadBusinesses());findViewById(R.id.btnRefresh).setOnClickListener(v->loadBusinesses());findViewById(R.id.btnAdd).setOnClickListener(v->{clearForm();show(addPanel);});findViewById(R.id.btnOwnerLogin).setOnClickListener(v->show(loginPanel));findViewById(R.id.btnRegister).setOnClickListener(v->show(registerPanel));findViewById(R.id.btnAdmin).setOnClickListener(v->adminLogin());findViewById(R.id.btnOffers).setOnClickListener(v->{loadOffers();show(offersPanel);});findViewById(R.id.btnService).setOnClickListener(v->show(servicePanel));
        findViewById(R.id.btnPhoto).setOnClickListener(v->takePhoto());findViewById(R.id.btnGallery).setOnClickListener(v->pickImages());findViewById(R.id.btnLocation).setOnClickListener(v->getLocation());findViewById(R.id.btnSave).setOnClickListener(v->saveBusiness());findViewById(R.id.btnBackAdd).setOnClickListener(v->showHome());findViewById(R.id.btnBackLogin).setOnClickListener(v->showHome());findViewById(R.id.btnBackRegister).setOnClickListener(v->showHome());
        findViewById(R.id.btnLogin).setOnClickListener(v->ownerLogin());findViewById(R.id.btnRegisterOwner).setOnClickListener(v->registerOwner());findViewById(R.id.btnOwnerEdit).setOnClickListener(v->ownerEdit());findViewById(R.id.btnOwnerOffers).setOnClickListener(v->{loadOwnerBusinesses();show(offersPanel);});findViewById(R.id.btnOwnerLogout).setOnClickListener(v->{auth.signOut();ensureAnon();showHome();});findViewById(R.id.btnAdminLogout).setOnClickListener(v->{adminMode=false;auth.signOut();ensureAnon();showHome();});
        findViewById(R.id.btnAddOffer).setOnClickListener(v->addOffer());findViewById(R.id.btnBackOffers).setOnClickListener(v->showHome());findViewById(R.id.btnSendComplaint).setOnClickListener(v->sendComplaint());findViewById(R.id.btnBackService).setOnClickListener(v->showHome());
        findViewById(R.id.btnAdminRequests).setOnClickListener(v->loadRequests());findViewById(R.id.btnAdminOwners).setOnClickListener(v->loadOwners());findViewById(R.id.btnAdminBusinesses).setOnClickListener(v->loadAdminBusinesses());findViewById(R.id.btnAdminOffers).setOnClickListener(v->loadAdminOffers());findViewById(R.id.btnAdminComplaints).setOnClickListener(v->loadComplaints());findViewById(R.id.btnAdminRatings).setOnClickListener(v->loadRatings());
    }
    void show(View v){homePanel.setVisibility(View.GONE);addPanel.setVisibility(View.GONE);loginPanel.setVisibility(View.GONE);registerPanel.setVisibility(View.GONE);ownerPanel.setVisibility(View.GONE);adminPanel.setVisibility(View.GONE);offersPanel.setVisibility(View.GONE);servicePanel.setVisibility(View.GONE);v.setVisibility(View.VISIBLE);}
    void showHome(){show(homePanel);adminMode=false;loadBusinesses();homeStatus.setText("☁️ البيانات متصلة بالسحابة. المنشآت الجديدة والتعديلات تمر بالمراجعة.");}
    void ensureAnon(){if(auth.getCurrentUser()==null)auth.signInAnonymously();}

    void loadBusinesses(){if(businessList==null||db==null)return;businessList.removeAllViews();Query q=db.collection("businesses").whereEqualTo("status","approved").whereEqualTo("active",true).limit(100);String c=searchCategory.getSelectedItem()==null?"الكل":searchCategory.getSelectedItem().toString();if(!"الكل".equals(c))q=q.whereEqualTo("category",c);q.get().addOnSuccessListener(s->{ArrayList<DocumentSnapshot> rows=new ArrayList<>();String term=search.getText().toString().trim().toLowerCase(Locale.ROOT);for(DocumentSnapshot d:s){String n=d.getString("name");String a=d.getString("address");if(term.isEmpty()||((n==null?"":n)+" "+(a==null?"":a)).toLowerCase(Locale.ROOT).contains(term))rows.add(d);}Collections.sort(rows,(x,y)->Boolean.compare(!Boolean.TRUE.equals(y.getBoolean("featured")),!Boolean.TRUE.equals(x.getBoolean("featured"))));if(rows.isEmpty())addText(businessList,"لا توجد منشآت مطابقة حاليًا.");for(DocumentSnapshot d:rows)addBusinessCard(d);}).addOnFailureListener(e->addText(businessList,"تعذر تحميل البيانات: "+e.getMessage()));}
    void addBusinessCard(DocumentSnapshot d){LinearLayout card=box();String n=d.getString("name");TextView t=tv("🏪 "+safe(n)+"\n📂 "+safe(d.getString("category"))+"\n📍 "+safe(d.getString("address"))+"\n📞 "+safe(d.getString("phone"))+"\n⭐ "+(d.getDouble("ratingAvg")==null?"جديد":String.format(Locale.US,"%.1f",d.getDouble("ratingAvg")))+(Boolean.TRUE.equals(d.getBoolean("featured"))?"  ⭐ مميز":""));card.addView(t);LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);Button map=btn("🗺️ الخريطة"),call=btn("📞 اتصال"),wa=btn("💬 واتساب"),rate=btn("⭐ تقييم");actions.addView(map);actions.addView(call);actions.addView(wa);actions.addView(rate);card.addView(actions);map.setOnClickListener(v->openMap(d));call.setOnClickListener(v->call(d.getString("phone")));wa.setOnClickListener(v->wa(d.getString("whatsapp")));rate.setOnClickListener(v->showRatingDialog(d.getId()));businessList.addView(card);}
    void loadOffers(){offersPanel.findViewById(R.id.offerForm).setVisibility(View.GONE);LinearLayout list=findViewById(R.id.offerList);list.removeAllViews();db.collection("offers").whereEqualTo("active",true).limit(100).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("🎁 "+safe(d.getString("title"))+"\n"+safe(d.getString("description"))+"\nخصم: "+safe(d.getString("discount"))));list.addView(c);}}).addOnFailureListener(e->addText(list,"تعذر تحميل العروض."));}
    void addOffer(){FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){offerStatus.setText("سجل دخول صاحب المنشأة أولًا.");return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(us->{String bid=us.getString("businessId");if(bid==null||bid.isEmpty()){offerStatus.setText("لا توجد منشأة مرتبطة بالحساب.");return;}Map<String,Object> m=new HashMap<>();m.put("businessId",bid);m.put("ownerUid",u.getUid());m.put("title",offerTitle.getText().toString().trim());m.put("description",offerDesc.getText().toString().trim());m.put("discount",offerDiscount.getText().toString().trim());m.put("active",false);m.put("status","pending");m.put("createdAt",FieldValue.serverTimestamp());db.collection("offers").add(m).addOnSuccessListener(x->{offerStatus.setText("✅ العرض أُرسل للمراجعة.");offerTitle.setText("");offerDesc.setText("");offerDiscount.setText("");});});}

    void saveBusiness(){FirebaseUser u=auth.getCurrentUser();String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("اكتب اسم المنشأة");return;}if(u==null){addStatus.setText("جارٍ الاتصال بالسحابة، حاول مرة أخرى.");return;}String id=editingBusinessId.isEmpty()?db.collection("businesses").document().getId():editingBusinessId;uploadImages(id,0,new ArrayList<>(),urls->{Map<String,Object>b=new HashMap<>();b.put("name",n);b.put("phone",phone.getText().toString().trim());b.put("whatsapp",whatsapp.getText().toString().trim());b.put("address",address.getText().toString().trim());b.put("description",description.getText().toString().trim());b.put("category",category.getSelectedItem().toString());b.put("lat",lat);b.put("lng",lng);b.put("images",urls);b.put("updatedAt",FieldValue.serverTimestamp());b.put("active",true);b.put("featured",false);if(editingBusinessId.isEmpty()){b.put("ownerUid",u.isAnonymous()?"":u.getUid());b.put("status","pending");b.put("createdAt",FieldValue.serverTimestamp());db.collection("businesses").document(id).set(b).addOnSuccessListener(x->{if(!u.isAnonymous()) db.collection("users").document(u.getUid()).update("businessId",id); addStatus.setText("✅ تم الإرسال للمراجعة. لن يظهر للعامة إلا بعد موافقة المدير.");}).addOnFailureListener(e->addStatus.setText("خطأ: "+e.getMessage()));}else{Map<String,Object> req=new HashMap<>();req.put("businessId",id);req.put("ownerUid",u.getUid());req.put("changes",b);req.put("status","pending");req.put("createdAt",FieldValue.serverTimestamp());db.collection("changeRequests").add(req).addOnSuccessListener(x->addStatus.setText("🕐 تم إرسال التعديل للمراجعة.")).addOnFailureListener(e->addStatus.setText("خطأ: "+e.getMessage()));}});}
    interface UploadDone{void ok(ArrayList<String> urls);} void uploadImages(String id,int i,ArrayList<String> urls,UploadDone done){if(i>=imageUris.size()){done.ok(urls);return;}Uri u=imageUris.get(i);StorageReference ref=storage.getReference().child("businessImages/"+id+"/"+System.currentTimeMillis()+".jpg");ref.putFile(u).continueWithTask(t->ref.getDownloadUrl()).addOnSuccessListener(uri->{urls.add(uri.toString());uploadImages(id,i+1,urls,done);}).addOnFailureListener(e->{addStatus.setText("تعذر رفع صورة؛ سيتم إكمال الحفظ بدونها.");uploadImages(id,i+1,urls,done);});}
    void ownerEdit(){FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){show(loginPanel);return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(d->{String bid=d.getString("businessId");if(bid==null||bid.isEmpty()){clearForm();show(addPanel);return;}db.collection("businesses").document(bid).get().addOnSuccessListener(b->{if(!b.exists())return;editingBusinessId=bid;fillBusiness(b);show(addPanel);});});}
    void loadOwnerBusinesses(){show(offersPanel);offersPanel.findViewById(R.id.offerForm).setVisibility(View.VISIBLE);loadOffers();}

    void registerOwner(){
        String ph=regPhone.getText().toString().trim();
        String pw=regPassword.getText().toString();
        String bn=regBusiness.getText().toString().trim();
        if(ph.isEmpty() || pw.length()<6 || bn.isEmpty()){
            regStatus.setText("اكتب اسم المنشأة والرقم وكلمة مرور 6 أحرف على الأقل.");
            return;
        }
        String email=loginEmail(ph);
        auth.createUserWithEmailAndPassword(email,pw)
            .addOnSuccessListener(r->{
                FirebaseUser u=r.getUser();
                if(u==null){regStatus.setText("تعذر إنشاء الحساب.");return;}
                Map<String,Object> m=new HashMap<>();
                m.put("role","owner");
                m.put("phone",ph);
                m.put("businessName",bn);
                m.put("businessId","");
                m.put("enabled",true);
                m.put("createdAt",FieldValue.serverTimestamp());
                db.collection("users").document(u.getUid()).set(m)
                    .addOnSuccessListener(x->{
                        regStatus.setText("✅ تم إنشاء الحساب. يمكنك الآن إضافة منشأتك.");
                        showOwner();
                    })
                    .addOnFailureListener(e->regStatus.setText("تم إنشاء الحساب لكن تعذر حفظ الملف."));
            })
            .addOnFailureListener(e->regStatus.setText("تعذر التسجيل: "+e.getMessage()));
    }
    void ownerLogin(){String ph=loginPhone.getText().toString().trim(),pw=loginPassword.getText().toString();auth.signInWithEmailAndPassword(loginEmail(ph),pw).addOnSuccessListener(r->db.collection("users").document(r.getUser().getUid()).get().addOnSuccessListener(d->{if(!Boolean.TRUE.equals(d.getBoolean("enabled"))){loginStatus.setText("⛔ الحساب موقوف بواسطة المدير.");auth.signOut();return;}showOwner();})).addOnFailureListener(e->loginStatus.setText("بيانات الدخول غير صحيحة أو الحساب غير موجود."));}
    void showOwner(){FirebaseUser u=auth.getCurrentUser();if(u==null){show(loginPanel);return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(d->{ownerInfo.setText("👤 "+safe(d.getString("businessName"))+"\n📞 "+safe(d.getString("phone"))+"\nالحساب مفعل: "+(Boolean.TRUE.equals(d.getBoolean("enabled"))?"نعم":"لا"));show(ownerPanel);});}
    String loginEmail(String phone){String x=phone.replaceAll("[^0-9]","");return x+"@negmdiarb.app";}

    void adminLogin(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,10,20,10);
        EditText em=new EditText(this); em.setHint("بريد المدير");
        EditText pw=new EditText(this); pw.setHint("كلمة المرور"); pw.setInputType(0x81); l.addView(em); l.addView(pw);
        new AlertDialog.Builder(this).setTitle("دخول المدير").setView(l).setPositiveButton("دخول",(d,w)->auth.signInWithEmailAndPassword(em.getText().toString().trim(),pw.getText().toString()).addOnSuccessListener(r->db.collection("users").document(r.getUser().getUid()).get().addOnSuccessListener(u->{if("admin".equals(u.getString("role")) && Boolean.TRUE.equals(u.getBoolean("enabled"))){adminMode=true;show(adminPanel);loadRequests();}else{auth.signOut();Toast.makeText(this,"الحساب ليس مديرًا.",Toast.LENGTH_SHORT).show();}})).addOnFailureListener(e->Toast.makeText(this,"بيانات المدير غير صحيحة.",Toast.LENGTH_SHORT).show())).setNegativeButton("إلغاء",null).show();
    }
    void loadRequests(){adminMode=true;requestList.removeAllViews();db.collection("changeRequests").whereEqualTo("status","pending").limit(100).get().addOnSuccessListener(s->{if(s.isEmpty())addText(requestList,"لا توجد طلبات معلقة.");for(DocumentSnapshot d:s){LinearLayout c=box();Map<String,Object> ch=(Map<String,Object>)d.get("changes");c.addView(tv("🕐 طلب تعديل\nالمنشأة: "+safe((String)ch.get("name"))));Button ok=btn("✅ موافقة"),no=btn("❌ رفض");LinearLayout a=new LinearLayout(this);a.addView(ok);a.addView(no);c.addView(a);ok.setOnClickListener(v->approveRequest(d));no.setOnClickListener(v->rejectRequest(d));requestList.addView(c);}}).addOnFailureListener(e->addText(requestList,"تعذر تحميل الطلبات."));}
    void approveRequest(DocumentSnapshot r){Map<String,Object> ch=(Map<String,Object>)r.get("changes");String bid=r.getString("businessId");db.collection("businesses").document(bid).set(ch,SetOptions.merge()).addOnSuccessListener(x->r.getReference().update("status","approved","reviewedAt",FieldValue.serverTimestamp()).addOnSuccessListener(y->{adminStatus.setText("تمت الموافقة");loadRequests();}));}
    void rejectRequest(DocumentSnapshot r){r.getReference().update("status","rejected","reviewedAt",FieldValue.serverTimestamp()).addOnSuccessListener(x->{adminStatus.setText("تم رفض الطلب");loadRequests();});}
    void loadOwners(){ownerList.removeAllViews();db.collection("users").whereEqualTo("role","owner").limit(100).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("👤 "+safe(d.getString("businessName"))+"\n📞 "+safe(d.getString("phone"))+"\nUID: "+d.getId()));Button b=btn(Boolean.TRUE.equals(d.getBoolean("enabled"))?"⛔ إيقاف":"✅ تفعيل");c.addView(b);b.setOnClickListener(v->d.getReference().update("enabled",!Boolean.TRUE.equals(d.getBoolean("enabled"))).addOnSuccessListener(x->loadOwners()));ownerList.addView(c);}});}
    void loadAdminBusinesses(){adminBusinessList.removeAllViews();db.collection("businesses").limit(200).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("🏪 "+safe(d.getString("name"))+"\nالحالة: "+safe(d.getString("status"))+" | مفعل: "+Boolean.TRUE.equals(d.getBoolean("active"))));Button b=btn(Boolean.TRUE.equals(d.getBoolean("active"))?"إخفاء":"إظهار");c.addView(b);b.setOnClickListener(v->d.getReference().update("active",!Boolean.TRUE.equals(d.getBoolean("active"))).addOnSuccessListener(x->loadAdminBusinesses()));adminBusinessList.addView(c);}});}
    void loadAdminOffers(){adminOfferList.removeAllViews();db.collection("offers").limit(200).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("🎁 "+safe(d.getString("title"))+"\nالحالة: "+safe(d.getString("status"))));Button b=btn(Boolean.TRUE.equals(d.getBoolean("active"))?"تعطيل":"اعتماد وتفعيل");c.addView(b);b.setOnClickListener(v->d.getReference().update("active",true,"status","approved").addOnSuccessListener(x->loadAdminOffers()));adminOfferList.addView(c);}});}
    void loadComplaints(){adminComplaintList.removeAllViews();db.collection("complaints").limit(200).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("📣 "+safe(d.getString("text"))+"\nالحالة: "+safe(d.getString("status"))));Button b=btn("إغلاق");c.addView(b);b.setOnClickListener(v->d.getReference().update("status","closed").addOnSuccessListener(x->loadComplaints()));adminComplaintList.addView(c);}});}
    void loadRatings(){
        adminRatingList.removeAllViews();
        db.collection("ratings").limit(200).get().addOnSuccessListener(s->{
            for(DocumentSnapshot d:s){
                Long stars=d.getLong("stars");
                LinearLayout c=box();
                c.addView(tv("⭐ "+(stars==null?"":String.valueOf(stars))+"\n"+safe(d.getString("text"))+"\nمنشأة: "+safe(d.getString("businessId"))));
                Button b=btn("حذف التقييم");
                c.addView(b);
                b.setOnClickListener(v->d.getReference().delete().addOnSuccessListener(x->loadRatings()));
                adminRatingList.addView(c);
            }
        });
    }
    void showRatingDialog(String bid){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"5","4","3","2","1"}));EditText tx=new EditText(this);tx.setHint("رأيك (اختياري)");l.addView(sp);l.addView(tx);new AlertDialog.Builder(this).setTitle("تقييم المنشأة").setView(l).setPositiveButton("إرسال",(d,w)->{Map<String,Object>m=new HashMap<>();m.put("businessId",bid);m.put("stars",Integer.parseInt(sp.getSelectedItem().toString()));m.put("text",tx.getText().toString().trim());m.put("status","pending");m.put("createdAt",FieldValue.serverTimestamp());db.collection("ratings").add(m).addOnSuccessListener(x->Toast.makeText(this,"تم إرسال التقييم للمراجعة",Toast.LENGTH_SHORT).show());}).setNegativeButton("إلغاء",null).show();}
    void sendComplaint(){String t=complaintText.getText().toString().trim();if(t.isEmpty()){serviceStatus.setText("اكتب الشكوى أو المقترح.");return;}Map<String,Object>m=new HashMap<>();m.put("text",t);m.put("status","open");m.put("createdAt",FieldValue.serverTimestamp());m.put("uid",auth.getCurrentUser()==null?"":auth.getCurrentUser().getUid());db.collection("complaints").add(m).addOnSuccessListener(x->{serviceStatus.setText("✅ تم إرسال البلاغ لخدمة العملاء.");complaintText.setText("");});}

    void takePhoto(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAM);return;}try{File dir=new File(getExternalFilesDir("Pictures"),"shops");dir.mkdirs();File f=new File(dir,"shop_"+System.currentTimeMillis()+".jpg");photoUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,100);}catch(Exception e){addStatus.setText("تعذر فتح الكاميرا.");}}
    void pickImages(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,GALLERY);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=Activity.RESULT_OK)return;if(r==100&&photoUri!=null){imageUris.add(photoUri);renderThumbs();runOcr(photoUri);}else if(r==GALLERY&&d!=null){if(d.getClipData()!=null)for(int i=0;i<d.getClipData().getItemCount();i++)addGalleryUri(d.getClipData().getItemAt(i).getUri());else if(d.getData()!=null)addGalleryUri(d.getData());renderThumbs();}}
    void addGalleryUri(Uri u){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(!imageUris.contains(u))imageUris.add(u);}
    void renderThumbs(){thumbs.removeAllViews();for(Uri u:imageUris){ImageView im=new ImageView(this);im.setImageURI(u);im.setScaleType(ImageView.ScaleType.CENTER_CROP);thumbs.addView(im,new LinearLayout.LayoutParams(95,95));}imageCount.setText("🖼️ عدد الصور: "+imageUris.size());}
    void runOcr(Uri u){try{InputImage img=InputImage.fromFilePath(this,u);TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img).addOnSuccessListener(res->{String t=res.getText();if(name.getText().length()==0&&!t.trim().isEmpty())name.setText(t.split("\\n")[0]);addStatus.setText("تمت محاولة قراءة الاسم؛ راجعه قبل الإرسال.");});}catch(Exception ignored){}}
    void getLocation(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOC);return;}fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,null).addOnSuccessListener(l->{if(l!=null){lat=l.getLatitude();lng=l.getLongitude();location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));}});}
    void clearForm(){editingBusinessId="";name.setText("");phone.setText("");whatsapp.setText("");address.setText("");description.setText("");lat=0;lng=0;location.setText("📍 لم يتم تحديد الموقع");imageUris.clear();renderThumbs();addStatus.setText("");}
    void fillBusiness(DocumentSnapshot b){name.setText(safe(b.getString("name")));phone.setText(safe(b.getString("phone")));whatsapp.setText(safe(b.getString("whatsapp")));address.setText(safe(b.getString("address")));description.setText(safe(b.getString("description")));lat=b.getDouble("lat")==null?0:b.getDouble("lat");lng=b.getDouble("lng")==null?0:b.getDouble("lng");location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));imageUris.clear();List<String> imgs=(List<String>)b.get("images");if(imgs!=null)for(String x:imgs)imageUris.add(Uri.parse(x));renderThumbs();}
    void openMap(DocumentSnapshot d){Double a=d.getDouble("lat"),b=d.getDouble("lng");if(a==null||b==null)return;Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/?api=1&query="+a+","+b));startActivity(i);}
    void call(String p){if(p==null||p.isEmpty())return;startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+p)));}
    void wa(String p){if(p==null||p.isEmpty())return;startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+p.replaceAll("[^0-9]",""))));}
    LinearLayout box(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(12,12,12,12);return l;} TextView tv(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setPadding(8,8,8,8);return t;} Button btn(String s){Button b=new Button(this);b.setText(s);return b;} void addText(LinearLayout l,String s){l.addView(tv(s));} String safe(String s){return s==null?"":s;}
}
