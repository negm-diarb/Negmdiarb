# نجم ديرب — V7 Cloud

نسخة Android متصلة بـ Firebase: Authentication + Cloud Firestore + Cloud Storage.

## ما تم إضافته
- بيانات سحابية بدل SharedPreferences.
- تسجيل أصحاب المنشآت عبر Firebase Authentication مع رقم الهاتف كواجهة دخول.
- إضافة منشأة جديدة بحالة pending ولا تظهر للعامة قبل اعتماد المدير.
- تعديل صاحب المنشأة ينشئ طلب مراجعة ولا يغيّر البيانات المنشورة مباشرة.
- لوحة مدير: طلبات، أصحاب منشآت، منشآت، عروض، شكاوى، تقييمات.
- صور متعددة من الجهاز + كاميرا + OCR + GPS.
- بحث وتصنيف ومنشآت مميزة وعروض وتقييمات وخدمة عملاء.

## إعداد Firebase المطلوب مرة واحدة
1. في Firebase Console فعّل Authentication > Sign-in method > Email/Password.
2. أنشئ Cloud Firestore Database.
3. أنشئ Storage.
4. انشر `firestore.rules` و`storage.rules` من Firebase Console.
5. أنشئ مستخدم مدير في Authentication ثم أنشئ له وثيقة في Firestore:
   `users/{UID}` بالحقول: `role: "admin"`, `enabled: true`.
6. لا تستخدم كلمة مرور مدير داخل التطبيق؛ صلاحيات المدير تعتمد على وثيقة role.

## ملاحظة
ملف `google-services.json` الموجود داخل `app/` خاص بمشروع Firebase الخاص بنجم ديرب.
