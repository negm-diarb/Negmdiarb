V25 Build Fix: fixes Java lambda compilation errors in staff manager reload and secondary FirebaseApp lifecycle. VersionCode 25. Keeps applicationId and stable signing.
