# Negm Diarb V24 — Permissions & Security Fix

- versionCode 24 / versionName 1.0-v24-permissions-security
- Same applicationId: com.negmdiarb.app
- Same release signing environment/secrets as previous versions.
- Admin-only creation of businesses, owners and staff.
- Staff roles: customer_service, establishment_reviewer, offers_manager.
- Owner cannot change role, enabled, or businessId from their own user document.
- Reviewer can mark a pending owner change request as reviewed; final publication remains admin-only.
- Offers manager can manage offers; customer service can manage complaints.
- Added staff management screen for the admin to view and enable/disable staff accounts.
- Added explicit permissions metadata to owner/staff user documents; Firestore rules still enforce access by role.
- Leaving the admin area through the Back confirmation returns to public home and signs the admin/staff session out, then starts an anonymous public session.
- Firestore rules in `firestore.rules` must be published in Firebase Console before testing account creation.
