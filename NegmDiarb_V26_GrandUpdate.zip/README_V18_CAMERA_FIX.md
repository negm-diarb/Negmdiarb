# Negm Diarb V18 – Camera Fix

Fixes the Add Business camera flow by preserving the add-business form and image state across Activity recreation while the camera app is open.

- Camera confirmation returns to Add Business instead of Home.
- Captured image is added to preview list.
- Images can be deleted before save.
- Multiple gallery images remain supported.
- Firebase/admin behavior retained.
- applicationId remains com.negmdiarb.app.
- versionCode 18.
