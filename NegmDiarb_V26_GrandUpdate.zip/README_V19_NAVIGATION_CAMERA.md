# Negm Diarb V19 — Navigation + Camera + Launcher Icon

- App always starts on the public home screen, even when an admin session is still signed in.
- Admin session remains authenticated; hidden admin entry opens the dashboard when explicitly requested.
- Camera result stays on Add Business and appends the captured photo to the preview list.
- Gallery multi-select and delete-before-save remain available.
- Added a launcher icon for the app.
- applicationId remains com.negmdiarb.app.
- versionCode: 19.
