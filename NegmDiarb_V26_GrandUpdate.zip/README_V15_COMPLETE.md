# نجم ديرب — V15 Complete

V15 builds on V14 while preserving the update chain:
- applicationId: com.negmdiarb.app
- versionCode: 15
- versionName: 1.0-v15-complete
- signed with the stable GitHub Actions keystore secrets

## Public experience
- Search by name, description, services, address, phone
- Quick categories: restaurants, shops, clinics, pharmacies, services, cafes, clothes, electronics, bakeries
- Nearby businesses with distance
- Favorites
- Featured businesses
- Offers
- Share, call, WhatsApp, website, Facebook, Google Maps navigation
- Business detail image gallery when imageUrls are available
- Complaints, suggestions, and technical issue submission
- Owner login without self-registration
- Public administration entry and staff login

## Administration
- Main admin controls adding/publishing/hiding/deleting businesses
- Main admin creates owner and staff accounts
- Owner accounts are linked to their business
- Owner changes are submitted for review
- Offers can be created by owners for review or directly by main admin
- Ratings require moderation
- Complaint management
- Analytics for businesses, offers, ratings, complaints, users, views, calls, WhatsApp, maps, favorites

## Security
- New businesses can only be created by an enabled admin in Firestore rules
- Owner change requests are limited to approved editable fields
- Storage writes are restricted to admin or the owner of the business path
- Public users cannot create businesses or owner accounts

## Update requirement
Do not uninstall V14 before testing V15. Keep the same applicationId and signing key and increase versionCode only.
