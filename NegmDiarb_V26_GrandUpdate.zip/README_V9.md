# نجم ديرب V9 — Complete MVP

- Android / Java / XML
- Firebase Authentication + Firestore
- No Firebase Storage dependency yet; images are selected/captured locally for preview only.
- Business approval + owner change requests + admin controls.
- Offers with dates and moderation.
- Ratings with moderation and aggregate average/count.
- Complaints/customer service.
- Favorites.
- Nearby sorting with location permission on demand.
- Search by name/address/services and category.
- Call / WhatsApp / Maps / Facebook / website.
- Admin analytics for basic collections and interaction events.
- Images can be reconnected to Firebase Storage later after enabling Blaze.
