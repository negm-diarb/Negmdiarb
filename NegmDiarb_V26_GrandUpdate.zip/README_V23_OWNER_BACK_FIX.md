# Negm Diarb V23 – Owner Permissions + Admin Back Fix

- versionCode: 23
- Same applicationId: com.negmdiarb.app
- Same stable signing configuration.
- Owner/employee account creation now verifies the primary admin session, saves the Firestore permissions document using that admin session, links the owner to the selected business, and cleans up the newly-created Auth account if permissions saving fails.
- Clear diagnostic message asks the admin to publish Firestore rules when the permissions document is rejected.
- Android Back from the admin dashboard now asks for confirmation before returning to the normal public home page.
- Android Back from the public home page still asks before exiting the app.
