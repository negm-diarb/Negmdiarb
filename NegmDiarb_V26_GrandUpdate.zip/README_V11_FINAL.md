# Negm Diarb V11 Final

## أهم التغييرات
- إضافة المنشآت أصبحت للإدارة فقط.
- منع إنشاء المنشأة من المستخدم العادي أو صاحب المنشأة عبر Firestore Rules.
- حفظ بيانات المنشأة في Firestore.
- رفع صور المنشأة إلى Firebase Storage وحفظ روابط الصور في `imageUrls`.
- حذف صورة منفردة من قائمة الصور قبل الحفظ.
- زر حذف كل الصور.
- التحقق من تحديد الموقع قبل الحفظ.
- البحث يشمل الاسم والعنوان والخدمات والوصف.
- versionCode = 11 / versionName = 1.0-v11-final.
- الحفاظ على applicationId: `com.negmdiarb.app`.

## Firebase
بعد تفعيل Cloud Storage، انشر محتوى `storage.rules` من هذا المشروع في Firebase Storage Rules.
وانشر `firestore.rules` في Firestore Rules.

## التوقيع
لإصدار تحديثات قابلة للتثبيت فوق النسخة السابقة، يجب أن تستخدم الإصدارات النهائية نفس مفتاح التوقيع. لا تعتمد على debug keystore جديد من كل GitHub runner.
