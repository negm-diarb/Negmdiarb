# Negm Diarb V16 — Admin Hidden

## Changes
- `versionCode 16`, `versionName 1.0-v16-admin-hidden`.
- Public **دخول الإدارة** button is hidden.
- Hidden admin entry: **7 quick taps on the ⭐ نجم ديرب title/logo**.
- Hidden entry is only a way to reach the login screen; real authorization is enforced by Firebase `role == admin` and `enabled == true`.
- Removed the anonymous-user `users` collection query that caused the misleading **تعذر التحقق من الإدارة. تأكد من الإنترنت** message.
- Admin session remains available through Firebase Auth persistence until the admin explicitly logs out.
- Android back behavior:
  - On the home screen: confirmation dialog before exiting.
  - On internal screens: back returns to home.
- Keeps the same `applicationId` and stable signing-key workflow so V16 can update V15 when the certificate matches.
- Firestore business creation remains restricted to the main admin.
