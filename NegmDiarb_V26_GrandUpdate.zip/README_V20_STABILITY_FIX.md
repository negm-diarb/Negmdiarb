# Negm Diarb V20 — Stability + Navigation + Camera Fix

## Fixes
- Firebase is initialized before the home screen performs any Firebase-dependent work.
- Prevented a startup crash caused by `loadFavorites()` accessing `auth` before Firebase initialization.
- App starts on the public home screen.
- A saved admin session remains authenticated without automatically opening the admin dashboard.
- If Android recreates the Activity during camera use, the Add Business form can be restored instead of being forced to Home.
- Camera result remains inside Add Business and adds the captured image to the preview.
- Gallery multi-select and delete-before-save remain available.
- Launcher icon remains the Negm Diarb icon.
- applicationId remains `com.negmdiarb.app`.
- versionCode: 20.
