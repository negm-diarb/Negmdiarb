V25 Build Fix: fixes Java compilation error in secondary FirebaseApp lifecycle by removing invalid final local assignment. VersionCode 25. Keeps applicationId and stable signing.
