# Negm Diarb V22 – Map & Storage Fix

- Version code: 22
- Keeps the same applicationId and release signing configuration.
- Hardens osmdroid initialization/cache so the map picker can load tiles reliably.
- Keeps individual image deletion and all-image deletion.
- Firestore business data is saved before image upload; Storage failure never discards saved business data.
- Firebase Storage still requires a provisioned Storage bucket/Blaze plan before cloud image uploads can succeed.
- The Android/iOS-friendly backend remains Firebase/Firestore/Storage.
