package com.negmdiarb.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.google.android.gms.location.*;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends ComponentActivity {
    LinearLayout root,homePanel,addPanel,loginPanel,registerPanel,ownerPanel,adminPanel,offersPanel,servicePanel,
            businessList,requestList,ownerList,adminBusinessList,adminOfferList,adminComplaintList,adminRatingList,thumbs;
    EditText name,phone,whatsapp,facebook,address,description,search,loginPhone,loginPassword,regBusiness,regPhone,regPassword,
            offerTitle,offerDesc,offerDiscount,complaintText,hours,services,website;
    Spinner category,searchCategory;
    TextView addStatus,loginStatus,regStatus,ownerInfo,homeStatus,imageCount,location,offerStatus,adminStatus,statsText,serviceStatus;
    Uri photoUri; File photoFile; final ArrayList<Uri> imageUris=new ArrayList<>();
    FusedLocationProviderClient fused; FirebaseAuth auth; FirebaseFirestore db; FirebaseStorage storage;
    double lat=0,lng=0; String editingBusinessId=""; final int CAM=10,LOC=11,GALLERY=12;
    boolean adminMode=false; String offerStartDate="",offerEndDate="";
    final Set<String> favoriteIds=new HashSet<>();

    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);bind();initFirebase();setup();showHome();}
    void bind(){
        root=findViewById(R.id.root); homePanel=findViewById(R.id.homePanel); addPanel=findViewById(R.id.addPanel); loginPanel=findViewById(R.id.loginPanel); registerPanel=findViewById(R.id.registerPanel); ownerPanel=findViewById(R.id.ownerPanel); adminPanel=findViewById(R.id.adminPanel); offersPanel=findViewById(R.id.offersPanel); servicePanel=findViewById(R.id.servicePanel);
        businessList=findViewById(R.id.businessList); requestList=findViewById(R.id.requestList); ownerList=findViewById(R.id.ownerList); adminBusinessList=findViewById(R.id.adminBusinessList); adminOfferList=findViewById(R.id.adminOfferList); adminComplaintList=findViewById(R.id.adminComplaintList); adminRatingList=findViewById(R.id.adminRatingList); thumbs=findViewById(R.id.thumbs);
        name=findViewById(R.id.name);phone=findViewById(R.id.phone);whatsapp=findViewById(R.id.whatsapp);facebook=findViewById(R.id.facebook);address=findViewById(R.id.address);description=findViewById(R.id.description);hours=findViewById(R.id.hours);services=findViewById(R.id.services);website=findViewById(R.id.website);search=findViewById(R.id.search);loginPhone=findViewById(R.id.loginPhone);loginPassword=findViewById(R.id.loginPassword);regBusiness=findViewById(R.id.regBusiness);regPhone=findViewById(R.id.regPhone);regPassword=findViewById(R.id.regPassword);offerTitle=findViewById(R.id.offerTitle);offerDesc=findViewById(R.id.offerDesc);offerDiscount=findViewById(R.id.offerDiscount);complaintText=findViewById(R.id.complaintText);
        category=findViewById(R.id.category);searchCategory=findViewById(R.id.searchCategory);
        addStatus=findViewById(R.id.addStatus);loginStatus=findViewById(R.id.loginStatus);regStatus=findViewById(R.id.regStatus);ownerInfo=findViewById(R.id.ownerInfo);homeStatus=findViewById(R.id.homeStatus);imageCount=findViewById(R.id.imageCount);location=findViewById(R.id.location);offerStatus=findViewById(R.id.offerStatus);adminStatus=findViewById(R.id.adminStatus);statsText=findViewById(R.id.statsText); serviceStatus=findViewById(R.id.serviceStatus);
    }
    void initFirebase(){auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();storage=FirebaseStorage.getInstance();fused=LocationServices.getFusedLocationProviderClient(this);if(auth.getCurrentUser()==null)auth.signInAnonymously().addOnCompleteListener(t->{loadFavorites();loadBusinesses();});else{loadFavorites();loadBusinesses();}}
    String[] cats={"الكل","مطاعم","محلات","عيادات","صيدليات","خدمات","ملابس","إلكترونيات","مقاهي","مخابز","أخرى"};
    void setup(){
        category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Arrays.copyOfRange(cats,1,cats.length)));
        searchCategory.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));
        findViewById(R.id.btnSearch).setOnClickListener(v->loadBusinesses()); findViewById(R.id.btnNearby).setOnClickListener(v->loadNearby()); findViewById(R.id.btnFavorites).setOnClickListener(v->loadFavoritesOnly()); findViewById(R.id.btnRefresh).setOnClickListener(v->loadBusinesses());
        findViewById(R.id.btnAdd).setOnClickListener(v->{if(!adminMode){Toast.makeText(this,"إضافة المنشآت متاحة للإدارة فقط.",Toast.LENGTH_SHORT).show();return;}clearForm();show(addPanel);});
        findViewById(R.id.btnAdminAddBusiness).setOnClickListener(v->{clearForm();show(addPanel);}); findViewById(R.id.btnOwnerLogin).setOnClickListener(v->show(loginPanel)); findViewById(R.id.btnRegister).setOnClickListener(v->show(registerPanel)); findViewById(R.id.btnAdmin).setOnClickListener(v->adminLogin());
        findViewById(R.id.btnOffers).setOnClickListener(v->{loadOffers();show(offersPanel);}); findViewById(R.id.btnService).setOnClickListener(v->show(servicePanel));
        findViewById(R.id.btnPhoto).setOnClickListener(v->takePhoto()); findViewById(R.id.btnGallery).setOnClickListener(v->pickImages()); findViewById(R.id.btnClearImages).setOnClickListener(v->clearAllImages()); findViewById(R.id.btnLocation).setOnClickListener(v->getLocation()); findViewById(R.id.btnMapPicker).setOnClickListener(v->openMapPicker()); findViewById(R.id.btnSave).setOnClickListener(v->saveBusiness()); findViewById(R.id.btnBackAdd).setOnClickListener(v->showHome()); findViewById(R.id.btnBackLogin).setOnClickListener(v->showHome()); findViewById(R.id.btnBackRegister).setOnClickListener(v->showHome());
        findViewById(R.id.btnLogin).setOnClickListener(v->ownerLogin()); findViewById(R.id.btnRegisterOwner).setOnClickListener(v->registerOwner()); findViewById(R.id.btnOwnerEdit).setOnClickListener(v->ownerEdit()); findViewById(R.id.btnOwnerRequests).setOnClickListener(v->loadOwnerRequests()); findViewById(R.id.btnOwnerOffers).setOnClickListener(v->{loadOwnerBusinesses();show(offersPanel);}); findViewById(R.id.btnOwnerLogout).setOnClickListener(v->{auth.signOut();ensureAnon();showHome();}); findViewById(R.id.btnAdminLogout).setOnClickListener(v->{adminMode=false;auth.signOut();ensureAnon();showHome();});
        findViewById(R.id.btnOfferStart).setOnClickListener(v->pickOfferDate(true)); findViewById(R.id.btnOfferEnd).setOnClickListener(v->pickOfferDate(false)); findViewById(R.id.btnAddOffer).setOnClickListener(v->addOffer()); findViewById(R.id.btnBackOffers).setOnClickListener(v->showHome()); findViewById(R.id.btnSendComplaint).setOnClickListener(v->sendComplaint()); findViewById(R.id.btnBackService).setOnClickListener(v->showHome());
        findViewById(R.id.btnAdminRequests).setOnClickListener(v->loadRequests()); findViewById(R.id.btnAdminOwners).setOnClickListener(v->loadOwners()); findViewById(R.id.btnAdminBusinesses).setOnClickListener(v->loadAdminBusinesses()); findViewById(R.id.btnAdminOffers).setOnClickListener(v->loadAdminOffers()); findViewById(R.id.btnAdminComplaints).setOnClickListener(v->loadComplaints()); findViewById(R.id.btnAdminRatings).setOnClickListener(v->loadRatings()); findViewById(R.id.btnAdminStats).setOnClickListener(v->loadAdminStats());
    }
    void show(View v){homePanel.setVisibility(View.GONE);addPanel.setVisibility(View.GONE);loginPanel.setVisibility(View.GONE);registerPanel.setVisibility(View.GONE);ownerPanel.setVisibility(View.GONE);adminPanel.setVisibility(View.GONE);offersPanel.setVisibility(View.GONE);servicePanel.setVisibility(View.GONE);v.setVisibility(View.VISIBLE);}
    void showHome(){show(homePanel);findViewById(R.id.btnAdd).setVisibility(View.GONE);adminMode=false;loadBusinesses();homeStatus.setText("☁️ البيانات السحابية متصلة. المراجعة قبل النشر مفعلة.");}
    void ensureAnon(){if(auth.getCurrentUser()==null)auth.signInAnonymously();}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String safe(String s){return s==null?"":s;}
    boolean truth(DocumentSnapshot d,String k){return Boolean.TRUE.equals(d.getBoolean(k));}

    void loadBusinesses(){
        if(db==null)return; businessList.removeAllViews();
        Query q=db.collection("businesses").whereEqualTo("status","approved").whereEqualTo("active",true).limit(200);
        String c=searchCategory.getSelectedItem()==null?"الكل":searchCategory.getSelectedItem().toString(); if(!"الكل".equals(c))q=q.whereEqualTo("category",c);
        q.get().addOnSuccessListener(s->{ArrayList<DocumentSnapshot> rows=new ArrayList<>();String term=search.getText().toString().trim().toLowerCase(Locale.ROOT);for(DocumentSnapshot d:s){String n=safe(d.getString("name")),a=safe(d.getString("address")),sv=safe(d.getString("services")),ds=safe(d.getString("description"));if(term.isEmpty()||(n+" "+a+" "+sv+" "+ds).toLowerCase(Locale.ROOT).contains(term))rows.add(d);}Collections.sort(rows,(x,y)->{int f=Boolean.compare(!truth(y,"featured"),!truth(x,"featured"));if(f!=0)return f;double ay=x.getDouble("ratingAvg")==null?0:x.getDouble("ratingAvg"),by=y.getDouble("ratingAvg")==null?0:y.getDouble("ratingAvg");return Double.compare(by,ay);});if(rows.isEmpty())addText(businessList,"لا توجد منشآت مطابقة حاليًا.");for(DocumentSnapshot d:rows)addBusinessCard(d);}).addOnFailureListener(e->addText(businessList,"تعذر تحميل البيانات: "+safe(e.getMessage())));
    }
    void loadFavorites(){favoriteIds.clear();FirebaseUser u=auth.getCurrentUser();if(u==null)return;db.collection("favorites").whereEqualTo("uid",u.getUid()).limit(500).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s)favoriteIds.add(safe(d.getString("businessId")));});}
    void loadFavoritesOnly(){businessList.removeAllViews();if(favoriteIds.isEmpty()){addText(businessList,"⭐ لا توجد منشآت محفوظة في المفضلة.");return;}db.collection("businesses").whereIn(FieldPath.documentId(),new ArrayList<>(favoriteIds).subList(0,Math.min(10,favoriteIds.size()))).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s)if(truth(d,"active")&&"approved".equals(d.getString("status")))addBusinessCard(d);if(s.isEmpty())addText(businessList,"لا توجد منشآت منشورة في المفضلة.");}).addOnFailureListener(e->{addText(businessList,"تعذر تحميل المفضلة. جرّب التحديث.");});}
    void addBusinessCard(DocumentSnapshot d){
        LinearLayout card=box();String n=safe(d.getString("name"));double avg=d.getDouble("ratingAvg")==null?0:d.getDouble("ratingAvg");long cnt=d.getLong("ratingCount")==null?0:d.getLong("ratingCount");
        String badge=truth(d,"featured")?"  ⭐ مميز":"";String fav=favoriteIds.contains(d.getId())?"❤️":"🤍";
        TextView t=tv("🏪 "+n+badge+"\n📂 "+safe(d.getString("category"))+"\n📍 "+safe(d.getString("address"))+"\n📞 "+safe(d.getString("phone"))+"\n⭐ "+(avg==0?"جديد":String.format(Locale.US,"%.1f (%d)",avg,cnt)));
        card.addView(t);LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);
        Button mapBtn=btn("🗺️"),callBtn=btn("📞"),waBtn=btn("💬"),rateBtn=btn("⭐"),favBtn=btn(fav);a.addView(mapBtn);a.addView(callBtn);a.addView(waBtn);a.addView(rateBtn);a.addView(favBtn);card.addView(a);
        card.setOnClickListener(v->{showBusinessDetails(d);});mapBtn.setOnClickListener(v->{openMap(d);});callBtn.setOnClickListener(v->{call(d.getString("phone"));});waBtn.setOnClickListener(v->wa(d.getId(),d.getString("whatsapp")));rateBtn.setOnClickListener(v->showRatingDialog(d.getId()));favBtn.setOnClickListener(v->{toggleFavorite(d.getId());favBtn.setText(favoriteIds.contains(d.getId())?"❤️":"🤍");});businessList.addView(card);
    }
    void showBusinessDetails(DocumentSnapshot d){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(18,10,18,10);
        double avg=d.getDouble("ratingAvg")==null?0:d.getDouble("ratingAvg");long cnt=d.getLong("ratingCount")==null?0:d.getLong("ratingCount");
        String title=safe(d.getString("name"));
        TextView head=tv("🏪 "+title);head.setTextSize(22);head.setTypeface(null,android.graphics.Typeface.BOLD);l.addView(head);
        l.addView(tv("📂 "+safe(d.getString("category"))));
        l.addView(tv(safe(d.getString("description"))));
        l.addView(tv("📍 "+safe(d.getString("address"))));
        l.addView(tv("📞 "+safe(d.getString("phone"))));
        l.addView(tv("🕒 "+safe(d.getString("hours"))));
        l.addView(tv("🛠️ "+safe(d.getString("services"))));
        String web=safe(d.getString("website")),fb=safe(d.getString("facebook"));
        l.addView(tv("⭐ "+(avg==0?"جديد":String.format(Locale.US,"%.1f من %d تقييم",avg,cnt))));
        LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.VERTICAL);
        Button map=btn("🗺️ التوجه للمكان عبر خرائط Google");a.addView(map);map.setOnClickListener(v->openMap(d));
        Button call=btn("📞 اتصال");a.addView(call);call.setOnClickListener(v->call(d.getString("phone")));
        Button wa=btn("💬 واتساب");a.addView(wa);wa.setOnClickListener(v->wa(d.getId(),d.getString("whatsapp")));
        if(!web.isEmpty()){Button wb=btn("🌐 الموقع الإلكتروني");a.addView(wb);wb.setOnClickListener(v->openExternal(web));}
        if(!fb.isEmpty()){Button f=btn("📘 فيسبوك");a.addView(f);f.setOnClickListener(v->openExternal(fb));}
        Button share=btn("📤 مشاركة المنشأة");a.addView(share);share.setOnClickListener(v->shareBusiness(d));
        Button r=btn("⭐ اكتب تقييمًا");a.addView(r);r.setOnClickListener(v->showRatingDialog(d.getId()));
        l.addView(a);
        new AlertDialog.Builder(this).setTitle("تفاصيل المنشأة").setView(l).setPositiveButton("إغلاق",null).show();
    }
    void openExternal(String url){String u=url.trim();if(!u.startsWith("http://")&&!u.startsWith("https://"))u="https://"+u;try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){Toast.makeText(this,"الرابط غير متاح.",Toast.LENGTH_SHORT).show();}}
    void shareBusiness(DocumentSnapshot d){String n=safe(d.getString("name")),a=safe(d.getString("address"));Double la=d.getDouble("lat"),lo=d.getDouble("lng");String msg="⭐ "+n+"\n📍 "+a;if(la!=null&&lo!=null)msg+="\n🗺️ https://www.google.com/maps/search/?api=1&query="+la+","+lo;Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,msg);startActivity(Intent.createChooser(i,"مشاركة المنشأة"));}
    void toggleFavorite(String bid){FirebaseUser u=auth.getCurrentUser();if(u==null)return;String id=u.getUid()+"_"+bid;DocumentReference r=db.collection("favorites").document(id);if(favoriteIds.contains(bid)){r.delete().addOnSuccessListener(x->{favoriteIds.remove(bid);});}else{Map<String,Object>m=new HashMap<>();m.put("uid",u.getUid());m.put("businessId",bid);m.put("createdAt",FieldValue.serverTimestamp());r.set(m).addOnSuccessListener(x->{favoriteIds.add(bid);});}}
    void logEvent(String collection,String bid){FirebaseUser u=auth.getCurrentUser();if(u==null)return;Map<String,Object>m=new HashMap<>();m.put("businessId",bid);m.put("uid",u.getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection(collection).add(m);}

    void loadNearby(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOC);return;}
        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,null).addOnSuccessListener(me->{if(me==null){homeStatus.setText("تعذر تحديد موقعك.");return;}db.collection("businesses").whereEqualTo("status","approved").whereEqualTo("active",true).limit(200).get().addOnSuccessListener(s->{ArrayList<DocumentSnapshot>rows=new ArrayList<>();for(DocumentSnapshot d:s)rows.add(d);final double la=me.getLatitude(),lo=me.getLongitude();Collections.sort(rows,(a,b)->Double.compare(distanceKm(la,lo,a),distanceKm(la,lo,b)));businessList.removeAllViews();if(rows.isEmpty())addText(businessList,"لا توجد منشآت منشورة.");for(DocumentSnapshot d:rows){addBusinessCard(d);businessList.addView(tv(String.format(Locale.US,"📏 %.2f كم",distanceKm(la,lo,d))));}homeStatus.setText("📍 تم ترتيب المنشآت من الأقرب إلى الأبعد.");});}).addOnFailureListener(e->homeStatus.setText("تعذر تحديد الموقع: "+safe(e.getMessage())));
    }
    double distanceKm(double la,double lo,DocumentSnapshot d){Double a=d.getDouble("lat"),b=d.getDouble("lng");if(a==null||b==null)return 999999;double R=6371.0,dl=Math.toRadians(a-la),do_=Math.toRadians(b-lo);double x=Math.sin(dl/2)*Math.sin(dl/2)+Math.cos(Math.toRadians(la))*Math.cos(Math.toRadians(a))*Math.sin(do_/2)*Math.sin(do_/2);return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));}

    void loadOffers(){
        offersPanel.findViewById(R.id.offerForm).setVisibility(View.GONE);LinearLayout list=findViewById(R.id.offerList);list.removeAllViews();String td=today();
        db.collection("offers").whereEqualTo("active",true).limit(200).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){String st=safe(d.getString("startDate")),en=safe(d.getString("endDate"));if(!en.isEmpty()&&en.compareTo(td)<0)continue;if(!st.isEmpty()&&st.compareTo(td)>0)continue;LinearLayout c=box();c.addView(tv("🎁 "+safe(d.getString("title"))+"\n"+safe(d.getString("description"))+"\n💰 "+safe(d.getString("discount"))+"\n📅 "+st+" → "+en));list.addView(c);}}).addOnFailureListener(e->addText(list,"تعذر تحميل العروض."));
    }
    void pickOfferDate(boolean start){Calendar c=Calendar.getInstance();new android.app.DatePickerDialog(this,(v,y,m,d)->{String s=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);if(start){offerStartDate=s;TextView t=findViewById(R.id.offerStartStatus);t.setVisibility(View.VISIBLE);t.setText("📅 بداية: "+s);}else{offerEndDate=s;TextView t=findViewById(R.id.offerEndStatus);t.setVisibility(View.VISIBLE);t.setText("📅 نهاية: "+s);}},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void addOffer(){FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){offerStatus.setText("سجل دخول صاحب المنشأة أولًا.");return;}String title=offerTitle.getText().toString().trim();if(title.isEmpty()){offerStatus.setText("اكتب عنوان العرض.");return;}if(!offerStartDate.isEmpty()&&!offerEndDate.isEmpty()&&offerEndDate.compareTo(offerStartDate)<0){offerStatus.setText("تاريخ النهاية يجب أن يكون بعد البداية.");return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(us->{String bid=safe(us.getString("businessId"));if(bid.isEmpty()){offerStatus.setText("لا توجد منشأة مرتبطة بالحساب.");return;}Map<String,Object>m=new HashMap<>();m.put("businessId",bid);m.put("ownerUid",u.getUid());m.put("startDate",offerStartDate);m.put("endDate",offerEndDate);m.put("title",title);m.put("description",offerDesc.getText().toString().trim());m.put("discount",offerDiscount.getText().toString().trim());m.put("active",false);m.put("status","pending");m.put("featured",false);m.put("createdAt",FieldValue.serverTimestamp());db.collection("offers").add(m).addOnSuccessListener(x->{offerStatus.setText("✅ العرض أُرسل للمراجعة.");offerTitle.setText("");offerDesc.setText("");offerDiscount.setText("");offerStartDate="";offerEndDate="";}).addOnFailureListener(e->offerStatus.setText("تعذر إرسال العرض: "+safe(e.getMessage())));});}

    void saveBusiness(){
        FirebaseUser u=auth.getCurrentUser();
        String n=name.getText().toString().trim();
        if(n.isEmpty()){name.setError("اكتب اسم المنشأة");return;}
        if(u==null||u.isAnonymous()){
            addStatus.setText("⛔ سجل الدخول بالحساب المناسب أولًا.");
            return;
        }
        if(lat==0&&lng==0){addStatus.setText("📍 حدد موقع المنشأة قبل الحفظ.");return;}

        if(adminMode){
            saveBusinessAsAdmin();
        }else{
            db.collection("users").document(u.getUid()).get().addOnSuccessListener(userDoc->{
                if(!"owner".equals(userDoc.getString("role")) || !truth(userDoc,"enabled")){
                    addStatus.setText("⛔ لا تملك صلاحية إرسال تعديل.");
                    return;
                }
                String bid=safe(userDoc.getString("businessId"));
                if(bid.isEmpty()){
                    addStatus.setText("ℹ️ الحساب غير مرتبط بمنشأة بعد. الربط يتم عن طريق الإدارة.");
                    return;
                }
                Map<String,Object> changes=businessFields(false);
                Map<String,Object> req=new HashMap<>();
                req.put("businessId",bid);
                req.put("ownerUid",u.getUid());
                req.put("changes",changes);
                req.put("status","pending");
                req.put("createdAt",FieldValue.serverTimestamp());
                addStatus.setText("☁️ جاري إرسال التعديل للمراجعة...");
                db.collection("changeRequests").add(req).addOnSuccessListener(x->{
                    addStatus.setText("✅ تم إرسال التعديل للإدارة. لن يظهر للعامة إلا بعد الموافقة.");
                    editingBusinessId=bid;
                }).addOnFailureListener(e->addStatus.setText("❌ تعذر إرسال الطلب: "+safe(e.getMessage())));
            }).addOnFailureListener(e->addStatus.setText("تعذر التحقق من الحساب."));
        }
    }

    Map<String,Object> businessFields(boolean adminCreate){
        Map<String,Object>b=new HashMap<>();
        b.put("name",name.getText().toString().trim());
        b.put("phone",phone.getText().toString().trim());
        b.put("whatsapp",normalizeEgyptPhone(whatsapp.getText().toString().trim()));
        b.put("facebook",facebook.getText().toString().trim());
        b.put("address",address.getText().toString().trim());
        b.put("description",description.getText().toString().trim());
        b.put("hours",hours.getText().toString().trim());
        b.put("services",services.getText().toString().trim());
        b.put("website",website.getText().toString().trim());
        b.put("category",category.getSelectedItem()==null?"أخرى":category.getSelectedItem().toString());
        b.put("lat",lat);b.put("lng",lng);
        if(adminCreate){
            b.put("ratingAvg",0);b.put("ratingCount",0);b.put("active",true);b.put("featured",false);b.put("ownerUid","");
            b.put("status","approved");b.put("updatedAt",FieldValue.serverTimestamp());
        }
        return b;
    }

    void saveBusinessAsAdmin(){
        final String id=editingBusinessId.isEmpty()?db.collection("businesses").document().getId():editingBusinessId;
        Map<String,Object>b=businessFields(true);
        if(editingBusinessId.isEmpty())b.put("createdAt",FieldValue.serverTimestamp());
        addStatus.setText("☁️ جاري رفع الصور وحفظ المنشأة...");
        uploadBusinessImages(id).addOnSuccessListener(urls->{
            if(!urls.isEmpty() || editingBusinessId.isEmpty()) b.put("imageUrls",urls);
            db.collection("businesses").document(id).set(b,SetOptions.merge()).addOnSuccessListener(x->{
                addStatus.setText("✅ تم حفظ المنشأة والصور على السحابة بنجاح.");
                editingBusinessId=id;
                loadBusinesses();
            }).addOnFailureListener(e->addStatus.setText("❌ تعذر حفظ بيانات المنشأة: "+safe(e.getMessage())));
        }).addOnFailureListener(e->addStatus.setText("❌ تعذر رفع الصور: "+safe(e.getMessage())));
    }

    Task<List<String>> uploadBusinessImages(String businessId){
        ArrayList<Task<Uri>> tasks=new ArrayList<>();
        for(int i=0;i<imageUris.size();i++){
            Uri u=imageUris.get(i);
            String name=""+System.currentTimeMillis()+"_"+i+".jpg";
            StorageReference ref=storage.getReference().child("businessImages").child(businessId).child(name);
            tasks.add(ref.putFile(u).continueWithTask(t->{if(!t.isSuccessful())throw Objects.requireNonNull(t.getException());return ref.getDownloadUrl();}));
        }
        return Tasks.whenAllSuccess(tasks).continueWith(t->{ArrayList<String> out=new ArrayList<>();for(Object o:t.getResult())out.add(((Uri)o).toString());return out;});
    }
    void ownerEdit(){FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){show(loginPanel);return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(d->{String bid=safe(d.getString("businessId"));if(bid.isEmpty()){Toast.makeText(this,"المنشأة يتم إنشاؤها وربطها بالحساب عن طريق الإدارة فقط.",Toast.LENGTH_LONG).show();return;}db.collection("businesses").document(bid).get().addOnSuccessListener(b->{if(b.exists()){editingBusinessId=bid;fillBusiness(b);addStatus.setText("✏️ عدّل البيانات ثم اضغط حفظ لإرسال طلب للمراجعة.");show(addPanel);}});});}
    void loadOwnerBusinesses(){offersPanel.findViewById(R.id.offerForm).setVisibility(View.VISIBLE);loadOffers();}
    void loadOwnerRequests(){FirebaseUser u=auth.getCurrentUser();if(u==null||u.isAnonymous()){show(loginPanel);return;}LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);db.collection("changeRequests").whereEqualTo("ownerUid",u.getUid()).limit(50).get().addOnSuccessListener(s->{if(s.isEmpty())l.addView(tv("لا توجد طلبات تعديل."));for(DocumentSnapshot d:s)l.addView(tv("🕐 الحالة: "+safe(d.getString("status"))+"
🏪 المنشأة: "+safe(d.getString("businessId"))));new AlertDialog.Builder(this).setTitle("طلبات التعديل").setView(l).setPositiveButton("إغلاق",null).show();});}

    void registerOwner(){String ph=regPhone.getText().toString().trim(),pw=regPassword.getText().toString(),bn=regBusiness.getText().toString().trim();if(ph.isEmpty()||pw.length()<6||bn.isEmpty()){regStatus.setText("اكتب اسم المنشأة والرقم وكلمة مرور 6 أحرف على الأقل.");return;}auth.createUserWithEmailAndPassword(loginEmail(ph),pw).addOnSuccessListener(r->{FirebaseUser u=r.getUser();if(u==null)return;Map<String,Object>m=new HashMap<>();m.put("role","owner");m.put("phone",ph);m.put("businessName",bn);m.put("businessId","");m.put("enabled",true);m.put("createdAt",FieldValue.serverTimestamp());db.collection("users").document(u.getUid()).set(m).addOnSuccessListener(x->{regStatus.setText("✅ تم إنشاء الحساب.");showOwner();}).addOnFailureListener(e->regStatus.setText("تم إنشاء الحساب لكن تعذر حفظ الملف."));}).addOnFailureListener(e->regStatus.setText("تعذر التسجيل: "+safe(e.getMessage())));}
    void ownerLogin(){String ph=loginPhone.getText().toString().trim(),pw=loginPassword.getText().toString();auth.signInWithEmailAndPassword(loginEmail(ph),pw).addOnSuccessListener(r->db.collection("users").document(r.getUser().getUid()).get().addOnSuccessListener(d->{if(!truth(d,"enabled")){loginStatus.setText("⛔ الحساب موقوف بواسطة المدير.");auth.signOut();return;}loadFavorites();showOwner();})).addOnFailureListener(e->loginStatus.setText("بيانات الدخول غير صحيحة أو الحساب غير موجود."));}
    void showOwner(){FirebaseUser u=auth.getCurrentUser();if(u==null){show(loginPanel);return;}db.collection("users").document(u.getUid()).get().addOnSuccessListener(d->{ownerInfo.setText("👤 "+safe(d.getString("businessName"))+"\n📞 "+safe(d.getString("phone"))+"\nحالة الحساب: "+(truth(d,"enabled")?"مفعل":"موقوف")+"\n🏪 المنشأة المرتبطة: "+safe(d.getString("businessId")));show(ownerPanel);});}
    String loginEmail(String p){return p.replaceAll("[^0-9]","")+"@negmdiarb.app";}

    void adminLogin(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);EditText em=new EditText(this);em.setHint("بريد المدير");EditText pw=new EditText(this);pw.setHint("كلمة المرور");pw.setInputType(0x81);l.addView(em);l.addView(pw);new AlertDialog.Builder(this).setTitle("دخول المدير").setView(l).setPositiveButton("دخول",(d,w)->auth.signInWithEmailAndPassword(em.getText().toString().trim(),pw.getText().toString()).addOnSuccessListener(r->db.collection("users").document(r.getUser().getUid()).get().addOnSuccessListener(u->{if("admin".equals(u.getString("role"))&&truth(u,"enabled")){adminMode=true;show(adminPanel);loadAdminStats();}else{auth.signOut();Toast.makeText(this,"الحساب ليس مديرًا.",Toast.LENGTH_SHORT).show();}})).addOnFailureListener(e->Toast.makeText(this,"بيانات المدير غير صحيحة.",Toast.LENGTH_SHORT).show())).setNegativeButton("إلغاء",null).show();}
    void loadAdminStats(){String[] cols={"businesses","offers","ratings","complaints","users"};StringBuilder out=new StringBuilder("📊 الإحصائيات\n");final int[] done={0};for(String c:cols){db.collection(c).get().addOnSuccessListener(s->{out.append("\n• ").append(c).append(": ").append(s.size());done[0]++;if(done[0]==cols.length)statsText.setText(out.toString());}).addOnFailureListener(e->{done[0]++;if(done[0]==cols.length)statsText.setText(out.toString()+"\n• بعض الإحصائيات غير متاحة");});}}
    void loadRequests(){adminMode=true;requestList.removeAllViews();db.collection("changeRequests").whereEqualTo("status","pending").limit(100).get().addOnSuccessListener(s->{if(s.isEmpty())addText(requestList,"لا توجد طلبات معلقة.");for(DocumentSnapshot d:s){LinearLayout c=box();Map<String,Object>ch=(Map<String,Object>)d.get("changes");c.addView(tv("🕐 طلب تعديل\nالمنشأة: "+safe(ch==null?"":(String)ch.get("name"))+"\nID: "+d.getString("businessId")));Button ok=btn("✅ موافقة"),no=btn("❌ رفض");LinearLayout a=new LinearLayout(this);a.addView(ok);a.addView(no);c.addView(a);ok.setOnClickListener(v->approveRequest(d));no.setOnClickListener(v->rejectRequest(d));requestList.addView(c);}}).addOnFailureListener(e->addText(requestList,"تعذر تحميل الطلبات."));}
    void approveRequest(DocumentSnapshot r){Map<String,Object>ch=(Map<String,Object>)r.get("changes");String bid=safe(r.getString("businessId"));if(ch==null||bid.isEmpty())return;db.collection("businesses").document(bid).set(ch,SetOptions.merge()).addOnSuccessListener(x->r.getReference().update("status","approved","reviewedAt",FieldValue.serverTimestamp()).addOnSuccessListener(y->{adminStatus.setText("تمت الموافقة على التعديل");loadRequests();}));}
    void rejectRequest(DocumentSnapshot r){r.getReference().update("status","rejected","reviewedAt",FieldValue.serverTimestamp()).addOnSuccessListener(x->{adminStatus.setText("تم رفض الطلب");loadRequests();});}
    void loadOwners(){ownerList.removeAllViews();db.collection("users").whereEqualTo("role","owner").limit(200).get().addOnSuccessListener(s->{if(s.isEmpty())addText(ownerList,"لا يوجد أصحاب منشآت.");for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("👤 "+safe(d.getString("businessName"))+"\n📞 "+safe(d.getString("phone"))+"\n🏪 "+safe(d.getString("businessId"))));Button b=btn(truth(d,"enabled")?"⛔ إيقاف الحساب":"✅ تفعيل الحساب");c.addView(b);b.setOnClickListener(v->d.getReference().update("enabled",!truth(d,"enabled")).addOnSuccessListener(x->loadOwners()));ownerList.addView(c);}});}
    void loadAdminBusinesses(){adminBusinessList.removeAllViews();db.collection("businesses").limit(300).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("🏪 "+safe(d.getString("name"))+"\nالحالة: "+safe(d.getString("status"))+" | مفعل: "+truth(d,"active")+" | مميز: "+truth(d,"featured")));LinearLayout a=new LinearLayout(this);String st=safe(d.getString("status"));if("pending".equals(st)){Button ok=btn("✅ اعتماد"),no=btn("❌ رفض");a.addView(ok);a.addView(no);ok.setOnClickListener(v->d.getReference().update("status","approved","active",true).addOnSuccessListener(x->loadAdminBusinesses()));no.setOnClickListener(v->d.getReference().update("status","rejected","active",false).addOnSuccessListener(x->loadAdminBusinesses()));}else{Button b=btn(truth(d,"active")?"إخفاء":"إظهار"),f=btn(truth(d,"featured")?"إلغاء المميز":"⭐ تمييز");a.addView(b);a.addView(f);b.setOnClickListener(v->d.getReference().update("active",!truth(d,"active")).addOnSuccessListener(x->loadAdminBusinesses()));f.setOnClickListener(v->d.getReference().update("featured",!truth(d,"featured")).addOnSuccessListener(x->loadAdminBusinesses()));}c.addView(a);adminBusinessList.addView(c);}});}
    void loadAdminOffers(){adminOfferList.removeAllViews();db.collection("offers").limit(300).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("🎁 "+safe(d.getString("title"))+"\nالحالة: "+safe(d.getString("status"))+" | فعال: "+truth(d,"active")));LinearLayout a=new LinearLayout(this);Button ok=btn("✅ اعتماد/تفعيل"),no=btn("❌ إيقاف");a.addView(ok);a.addView(no);c.addView(a);ok.setOnClickListener(v->d.getReference().update("active",true,"status","approved").addOnSuccessListener(x->loadAdminOffers()));no.setOnClickListener(v->d.getReference().update("active",false,"status","rejected").addOnSuccessListener(x->loadAdminOffers()));adminOfferList.addView(c);}});}
    void loadComplaints(){adminComplaintList.removeAllViews();db.collection("complaints").limit(300).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){LinearLayout c=box();c.addView(tv("📣 "+safe(d.getString("text"))+"\nالحالة: "+safe(d.getString("status"))));Button b=btn("إغلاق");c.addView(b);b.setOnClickListener(v->d.getReference().update("status","closed","updatedAt",FieldValue.serverTimestamp()).addOnSuccessListener(x->loadComplaints()));adminComplaintList.addView(c);}});}
    void loadRatings(){adminRatingList.removeAllViews();db.collection("ratings").limit(300).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){Long stars=d.getLong("stars");LinearLayout c=box();c.addView(tv("⭐ "+(stars==null?"":stars)+"\n"+safe(d.getString("text"))+"\nمنشأة: "+safe(d.getString("businessId"))+"\nالحالة: "+safe(d.getString("status"))));Button b=btn("pending".equals(d.getString("status"))?"✅ اعتماد":"🗑️ حذف");c.addView(b);b.setOnClickListener(v->{if("pending".equals(d.getString("status")))approveRating(d);else d.getReference().delete().addOnSuccessListener(x->loadRatings());});adminRatingList.addView(c);}});}
    void approveRating(DocumentSnapshot d){d.getReference().update("status","approved").addOnSuccessListener(x->{String bid=d.getString("businessId");db.collection("ratings").whereEqualTo("businessId",bid).whereEqualTo("status","approved").get().addOnSuccessListener(s->{double sum=0;int n=0;for(DocumentSnapshot r:s){Long st=r.getLong("stars");if(st!=null){sum+=st;n++;}}db.collection("businesses").document(bid).update("ratingAvg",n==0?0:sum/n,"ratingCount",n).addOnCompleteListener(q->loadRatings());});});}

    void showRatingDialog(String bid){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,10,20,10);Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"5","4","3","2","1"}));EditText tx=new EditText(this);tx.setHint("رأيك (اختياري)");l.addView(sp);l.addView(tx);new AlertDialog.Builder(this).setTitle("تقييم المنشأة").setView(l).setPositiveButton("إرسال",(d,w)->{FirebaseUser u=auth.getCurrentUser();Map<String,Object>m=new HashMap<>();m.put("businessId",bid);m.put("stars",Integer.parseInt(sp.getSelectedItem().toString()));m.put("text",tx.getText().toString().trim());m.put("status","pending");m.put("uid",u==null?"":u.getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection("ratings").add(m).addOnSuccessListener(x->Toast.makeText(this,"تم إرسال التقييم للمراجعة",Toast.LENGTH_SHORT).show());}).setNegativeButton("إلغاء",null).show();}
    void sendComplaint(){String t=complaintText.getText().toString().trim();if(t.isEmpty()){serviceStatus.setText("اكتب الشكوى أو المقترح.");return;}Map<String,Object>m=new HashMap<>();m.put("text",t);m.put("status","open");m.put("type","complaint");m.put("createdAt",FieldValue.serverTimestamp());m.put("uid",auth.getCurrentUser()==null?"":auth.getCurrentUser().getUid());db.collection("complaints").add(m).addOnSuccessListener(x->{serviceStatus.setText("✅ تم إرسال البلاغ لخدمة العملاء.");complaintText.setText("");});}

    void takePhoto(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAM);return;}try{File dir=new File(getExternalFilesDir("Pictures"),"shops");if(!dir.exists())dir.mkdirs();photoFile=new File(dir,"shop_"+System.currentTimeMillis()+".jpg");photoUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",photoFile);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("output",photoUri));startActivityForResult(i,100);}catch(Exception e){addStatus.setText("تعذر فتح الكاميرا: "+safe(e.getMessage()));}}
    void pickImages(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,GALLERY);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==100){boolean captured=(c==Activity.RESULT_OK)||(photoFile!=null&&photoFile.exists()&&photoFile.length()>1000);if(captured&&photoUri!=null){if(!imageUris.contains(photoUri))imageUris.add(photoUri);renderThumbs();runOcr(photoUri);addStatus.setText("✅ تمت إضافة الصورة. يمكنك حذفها قبل الحفظ.");}else addStatus.setText("لم يتم حفظ الصورة.");return;}if(r==GALLERY&&c==Activity.RESULT_OK&&d!=null){if(d.getClipData()!=null)for(int i=0;i<d.getClipData().getItemCount();i++)addGalleryUri(d.getClipData().getItemAt(i).getUri());else if(d.getData()!=null)addGalleryUri(d.getData());renderThumbs();}}
    void addGalleryUri(Uri u){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(!imageUris.contains(u))imageUris.add(u);}
    void clearAllImages(){imageUris.clear();renderThumbs();addStatus.setText("🗑️ تم حذف كل الصور من قائمة الحفظ.");}
    void renderThumbs(){thumbs.removeAllViews();for(int i=0;i<imageUris.size();i++){final int idx=i;LinearLayout w=box();ImageView im=new ImageView(this);im.setImageURI(imageUris.get(i));im.setScaleType(ImageView.ScaleType.CENTER_CROP);w.addView(im,new LinearLayout.LayoutParams(95,75));Button del=btn("❌ حذف");del.setOnClickListener(v->{if(idx<imageUris.size()){imageUris.remove(idx);renderThumbs();}});w.addView(del,new LinearLayout.LayoutParams(95,40));thumbs.addView(w,new LinearLayout.LayoutParams(105,120));}imageCount.setText("🖼️ عدد الصور: "+imageUris.size());}
    void runOcr(Uri u){try{InputImage img=InputImage.fromFilePath(this,u);TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img).addOnSuccessListener(res->{String t=res.getText();if(name.getText().length()==0&&!t.trim().isEmpty())name.setText(t.split("\\n")[0]);addStatus.setText("تمت محاولة قراءة الاسم من الصورة؛ راجعه.");});}catch(Exception ignored){}}
    void getLocation(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOC);return;}fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,null).addOnSuccessListener(l->{if(l!=null){lat=l.getLatitude();lng=l.getLongitude();location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));}});}
    void clearForm(){editingBusinessId="";name.setText("");phone.setText("");whatsapp.setText("");facebook.setText("");address.setText("");description.setText("");hours.setText("");services.setText("");website.setText("");lat=0;lng=0;location.setText("📍 لم يتم تحديد الموقع");imageUris.clear();renderThumbs();addStatus.setText("");}
    void fillBusiness(DocumentSnapshot b){name.setText(safe(b.getString("name")));phone.setText(safe(b.getString("phone")));whatsapp.setText(safe(b.getString("whatsapp")));facebook.setText(safe(b.getString("facebook")));address.setText(safe(b.getString("address")));description.setText(safe(b.getString("description")));hours.setText(safe(b.getString("hours")));services.setText(safe(b.getString("services")));website.setText(safe(b.getString("website")));lat=b.getDouble("lat")==null?0:b.getDouble("lat");lng=b.getDouble("lng")==null?0:b.getDouble("lng");location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));imageUris.clear();renderThumbs();}
    void openMap(DocumentSnapshot d){Double a=d.getDouble("lat"),b=d.getDouble("lng");if(a==null||b==null){Toast.makeText(this,"موقع المنشأة غير متاح.",Toast.LENGTH_SHORT).show();return;}navigateToMap(a,b,safe(d.getString("name")));}
    void navigateToMap(double a,double b,String label){
        Uri nav=Uri.parse("https://www.google.com/maps/dir/?api=1&destination="+a+","+b+(label==null||label.isEmpty()?"":"&destination_place_id="));
        Intent i=new Intent(Intent.ACTION_VIEW,nav);
        try{startActivity(i);}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:"+a+","+b+"?q="+a+","+b+"("+Uri.encode(label==null?"الموقع":label)+")")));}
    }

    void openMapPicker(){
        final WebView web=new WebView(this);
        web.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        WebSettings ws=web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setBuiltInZoomControls(false);
        final AlertDialog dlg=new AlertDialog.Builder(this).setTitle("🗺️ اختيار موقع المنشأة").setView(web).setNegativeButton("إلغاء",null).create();
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void setLocation(double la,double lo){
                runOnUiThread(()->{lat=la;lng=lo;location.setText(String.format(Locale.US,"📍 %.6f, %.6f",lat,lng));addStatus.setText("✅ تم اختيار موقع المنشأة من الخريطة.");});
            }
        },"Android");
        double startLat=(lat!=0)?lat:30.710099, startLng=(lng!=0)?lng:31.415552;
        String html=""+
            "<!doctype html><html dir='rtl'><head><meta name='viewport' content='width=device-width,initial-scale=1.0'>"+
            "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'>"+
            "<style>html,body,#map{height:100%;margin:0} .tip{position:absolute;z-index:9999;top:10px;left:10px;right:10px;background:white;padding:10px;border-radius:12px;text-align:center;font-family:sans-serif;box-shadow:0 2px 8px #7778}</style></head>"+
            "<body><div id='map'></div><div class='tip'>اضغط على الخريطة لتحديد موقع المنشأة 📍</div>"+
            "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"+
            "<script>var map=L.map('map').setView(["+startLat+","+startLng+"],15);"+
            "L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);"+
            "var marker=L.marker(["+startLat+","+startLng+"],{draggable:true}).addTo(map);"+
            "function pick(e){marker.setLatLng(e.latlng);Android.setLocation(e.latlng.lat,e.latlng.lng);}"+
            "map.on('click',pick);marker.on('dragend',function(e){var p=e.target.getLatLng();Android.setLocation(p.lat,p.lng);});</script></body></html>";
        web.loadDataWithBaseURL("https://negmdiarb.local/",html,"text/html","UTF-8",null);
        dlg.show();
        dlg.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.96),(int)(getResources().getDisplayMetrics().heightPixels*0.82));
    }
    void call(String p){if(p==null||p.isEmpty())return;startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+p)));}
    void wa(String bid,String p){if(p==null||p.isEmpty()){Toast.makeText(this,"لا يوجد رقم واتساب لهذه المنشأة.",Toast.LENGTH_SHORT).show();return;}String n=normalizeEgyptPhone(p).replace("+","");String msg="مرحبًا، وصلت إليكم عن طريق تطبيق نجم ديرب.";try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+n+"?text="+Uri.encode(msg))));}catch(Exception e){Toast.makeText(this,"تعذر فتح واتساب.",Toast.LENGTH_SHORT).show();}}
    String normalizeEgyptPhone(String p){if(p==null)return "";String x=p.trim().replaceAll("[^0-9+]","");if(x.startsWith("+20"))return x;if(x.startsWith("20"))return "+"+x;if(x.startsWith("0"))return "+20"+x.substring(1);return x;}
    LinearLayout box(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(14,14,14,14);l.setBackgroundResource(com.negmdiarb.app.R.drawable.bg_card);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,10);l.setLayoutParams(p);return l;}TextView tv(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setTextColor(android.graphics.Color.rgb(23,32,51));t.setPadding(6,6,6,6);return t;}Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setMinHeight(0);b.setPadding(4,0,4,0);b.setBackgroundResource(com.negmdiarb.app.R.drawable.bg_card);return b;}void addText(LinearLayout l,String s){l.addView(tv(s));}
}
